import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type UserRole = 'admin' | 'trainer' | 'client';

export interface Profile {
  id: string;
  full_name: string;
  role: UserRole;
  phone: string;
  avatar_url: string;
  created_at: string;
  updated_at: string;
}

export interface Membership {
  id: string;
  name: string;
  duration_days: number;
  price: number;
  description: string;
  features: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Client {
  id: string;
  user_id: string | null;
  first_name: string;
  last_name: string;
  document_number: string;
  phone: string;
  email: string;
  address: string;
  birth_date: string | null;
  gender: 'male' | 'female' | 'other' | '';
  photo_url: string;
  membership_id: string | null;
  trainer_id: string | null;
  start_date: string | null;
  end_date: string | null;
  status: 'active' | 'inactive' | 'expired' | 'pending';
  notes: string;
  created_at: string;
  updated_at: string;
  memberships?: Membership;
  trainers?: Trainer;
}

export interface Trainer {
  id: string;
  user_id: string | null;
  full_name: string;
  specialty: string;
  phone: string;
  email: string;
  bio: string;
  photo_url: string;
  schedule: Record<string, unknown>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Payment {
  id: string;
  client_id: string;
  membership_id: string | null;
  amount: number;
  payment_method: 'cash' | 'card' | 'transfer' | 'nequi' | 'daviplata';
  payment_date: string;
  reference: string;
  status: 'completed' | 'pending' | 'cancelled';
  notes: string;
  created_at: string;
  clients?: Client;
  memberships?: Membership;
}

export interface Routine {
  id: string;
  client_id: string;
  trainer_id: string | null;
  title: string;
  description: string;
  days_per_week: number;
  duration_weeks: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  goal: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  clients?: Client;
  trainers?: Trainer;
  exercises?: Exercise[];
}

export interface Exercise {
  id: string;
  routine_id: string;
  name: string;
  muscle_group: string;
  sets: number;
  reps: string;
  rest_seconds: number;
  notes: string;
  day_number: number;
  order_index: number;
  created_at: string;
}

export interface Attendance {
  id: string;
  client_id: string;
  check_in: string;
  check_out: string | null;
  notes: string;
  created_at: string;
  clients?: Client;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  is_read: boolean;
  created_at: string;
}

export interface GymSettings {
  id: string;
  gym_name: string;
  slogan: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  logo_url: string;
  cover_url: string;
  facebook: string;
  instagram: string;
  twitter: string;
  tax_rate: number;
  currency: string;
  currency_symbol: string;
  opening_time: string;
  closing_time: string;
  updated_at: string;
}
