import { Navigate, useLocation } from 'react-router-dom';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import { useAuth } from '../context/AuthContext';
import type { UserRole } from '../lib/supabase';

interface Props {
  children: React.ReactNode;
  requiredRoles?: UserRole[];
  redirectTo?: string;
}

export function ProtectedRoute({ children, requiredRoles, redirectTo = '/login' }: Props) {
  const { user, profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', bgcolor: 'background.default' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!user) return <Navigate to={redirectTo} state={{ from: location }} replace />;

  if (requiredRoles && profile && !requiredRoles.includes(profile.role)) {
    if (profile.role === 'client') return <Navigate to="/portal" replace />;
    return <Navigate to="/admin" replace />;
  }

  return <>{children}</>;
}

export function PublicOnlyRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', bgcolor: 'background.default' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (user) {
    if (profile?.role === 'client') return <Navigate to="/portal" replace />;
    return <Navigate to="/admin" replace />;
  }

  return <>{children}</>;
}
