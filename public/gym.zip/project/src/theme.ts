import { createTheme, responsiveFontSizes } from '@mui/material/styles';

let theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#FF6B35',
      light: '#FF8C5A',
      dark: '#E55A25',
      contrastText: '#fff',
    },
    secondary: {
      main: '#1DB954',
      light: '#3DD66F',
      dark: '#159C42',
      contrastText: '#fff',
    },
    background: {
      default: '#0A0A0A',
      paper: '#141414',
    },
    text: {
      primary: '#FFFFFF',
      secondary: '#A0A0A0',
    },
    error: { main: '#FF4444' },
    warning: { main: '#FFB800' },
    success: { main: '#1DB954' },
    info: { main: '#2196F3' },
    divider: 'rgba(255,255,255,0.08)',
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h1: { fontWeight: 800, letterSpacing: '-0.02em' },
    h2: { fontWeight: 700, letterSpacing: '-0.01em' },
    h3: { fontWeight: 700 },
    h4: { fontWeight: 700 },
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },
    button: { fontWeight: 600, textTransform: 'none' as const },
  },
  shape: { borderRadius: 12 },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          scrollbarColor: '#333 #0A0A0A',
          '&::-webkit-scrollbar': { width: 6 },
          '&::-webkit-scrollbar-track': { background: '#0A0A0A' },
          '&::-webkit-scrollbar-thumb': { background: '#333', borderRadius: 3 },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: 'none' as const,
          fontWeight: 600,
        },
        containedPrimary: {
          background: 'linear-gradient(135deg, #FF6B35 0%, #FF8C5A 100%)',
          boxShadow: '0 4px 20px rgba(255,107,53,0.4)',
          '&:hover': {
            background: 'linear-gradient(135deg, #E55A25 0%, #FF6B35 100%)',
            boxShadow: '0 6px 25px rgba(255,107,53,0.5)',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          background: '#141414',
          border: '1px solid rgba(255,255,255,0.06)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
          background: '#141414',
        },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          background: '#0D0D0D',
          borderRight: '1px solid rgba(255,255,255,0.06)',
        },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          background: 'rgba(10,10,10,0.95)',
          backdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
          boxShadow: 'none',
        },
      },
    },
    MuiTextField: {
      defaultProps: { variant: 'outlined' as const, size: 'small' as const },
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            '& fieldset': { borderColor: 'rgba(255,255,255,0.12)' },
            '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.25)' },
          },
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: { borderColor: 'rgba(255,255,255,0.06)' },
        head: {
          background: '#1A1A1A',
          fontWeight: 700,
          color: '#A0A0A0',
          textTransform: 'uppercase' as const,
          fontSize: '0.7rem',
          letterSpacing: '0.08em',
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 600 },
      },
    },
  },
});

theme = responsiveFontSizes(theme);
export default theme;
