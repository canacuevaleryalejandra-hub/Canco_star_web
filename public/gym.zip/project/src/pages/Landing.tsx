import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Chip from '@mui/material/Chip';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Divider from '@mui/material/Divider';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Avatar from '@mui/material/Avatar';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import StarIcon from '@mui/icons-material/Star';
import PeopleIcon from '@mui/icons-material/People';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import LocalFireDepartmentIcon from '@mui/icons-material/LocalFireDepartment';
import { useNavigate } from 'react-router-dom';

const plans = [
  { name: 'Diario', price: '15.000', period: '/día', features: ['Acceso a todas las áreas', 'Casillero incluido'], popular: false, duration: 'day' },
  { name: 'Semanal', price: '60.000', period: '/semana', features: ['Acceso a todas las áreas', 'Casillero incluido', 'Evaluación física'], popular: false, duration: 'week' },
  { name: 'Mensual', price: '120.000', period: '/mes', features: ['Acceso a todas las áreas', 'Casillero incluido', 'Evaluación física', '1 sesión con entrenador'], popular: true, duration: 'month' },
  { name: 'Trimestral', price: '320.000', period: '/3 meses', features: ['Todo lo de Mensual', '3 sesiones con entrenador', 'Plan nutricional'], popular: false, duration: 'quarter' },
  { name: 'Anual', price: '1.100.000', period: '/año', features: ['Todo lo de Trimestral', 'Sesiones ilimitadas', 'Acceso 24/7'], popular: false, duration: 'year' },
];

const trainers = [
  { name: 'Carlos Rodríguez', specialty: 'Musculación & Fuerza', rating: 4.9, clients: 48, experience: '8 años', initials: 'CR', color: '#FF6B35' },
  { name: 'Andrea Martínez', specialty: 'CrossFit & Funcional', rating: 4.8, clients: 35, experience: '6 años', initials: 'AM', color: '#1DB954' },
  { name: 'Diego Herrera', specialty: 'Cardio & Resistencia', rating: 4.7, clients: 42, experience: '10 años', initials: 'DH', color: '#2196F3' },
  { name: 'Laura Gómez', specialty: 'Yoga & Pilates', rating: 5.0, clients: 29, experience: '5 años', initials: 'LG', color: '#FFB800' },
];

const testimonials = [
  { name: 'María García', text: 'Transformé mi cuerpo en 6 meses. Los entrenadores son increíbles y el ambiente es motivador.', rating: 5, months: '6 meses' },
  { name: 'Juan Pérez', text: 'El mejor gimnasio de la ciudad. Equipos modernos y atención personalizada de primer nivel.', rating: 5, months: '1 año' },
  { name: 'Sofía Torres', text: 'Bajé 15kg y gané músculo. La metodología de entrenamiento es efectiva y muy profesional.', rating: 5, months: '8 meses' },
];

const schedules = [
  { day: 'Lunes - Viernes', hours: '5:00 AM - 10:00 PM' },
  { day: 'Sábados', hours: '6:00 AM - 8:00 PM' },
  { day: 'Domingos', hours: '7:00 AM - 6:00 PM' },
  { day: 'Festivos', hours: '8:00 AM - 4:00 PM' },
];

export default function Landing() {
  const navigate = useNavigate();

  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh' }}>
      {/* Navbar */}
      <AppBar position="sticky" elevation={0}>
        <Toolbar sx={{ justifyContent: 'space-between', px: { xs: 2, md: 6 } }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <LocalFireDepartmentIcon sx={{ color: 'primary.main', fontSize: 32 }} />
            <Typography variant="h5" sx={{ fontWeight: 800, color: 'white', letterSpacing: '-0.02em' }}>
              FitPro<span style={{ color: '#FF6B35' }}>Gym</span>
            </Typography>
          </Box>
          <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 3, alignItems: 'center' }}>
            {['Inicio', 'Planes', 'Entrenadores', 'Horarios', 'Contacto'].map(item => (
              <Typography key={item} sx={{ color: 'text.secondary', cursor: 'pointer', '&:hover': { color: 'primary.main' }, transition: 'color 0.2s' }}>
                {item}
              </Typography>
            ))}
            <Button variant="outlined" size="small" onClick={() => navigate('/login')} sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'white' }}>
              Iniciar Sesión
            </Button>
            <Button variant="contained" size="small" onClick={() => navigate('/register')}>
              Únete Ahora
            </Button>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Hero */}
      <Box sx={{
        minHeight: '90vh',
        display: 'flex',
        alignItems: 'center',
        position: 'relative',
        overflow: 'hidden',
        background: 'linear-gradient(135deg, #0A0A0A 0%, #1A0A00 50%, #0A0A0A 100%)',
        '&::before': {
          content: '""',
          position: 'absolute',
          inset: 0,
          background: 'radial-gradient(ellipse at 60% 50%, rgba(255,107,53,0.15) 0%, transparent 70%)',
        },
      }}>
        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
          <Grid container spacing={4} alignItems="center">
            <Grid size={{ xs: 12, md: 7 }}>
              <Chip label="⚡ El Gimnasio #1 de la Ciudad" sx={{ mb: 3, bgcolor: 'rgba(255,107,53,0.15)', color: 'primary.main', fontWeight: 600 }} />
              <Typography variant="h1" sx={{ fontSize: { xs: '2.5rem', md: '4.5rem' }, mb: 2, lineHeight: 1.1 }}>
                Transforma Tu<br />
                <Box component="span" sx={{ color: 'primary.main' }}>Cuerpo.</Box> Eleva Tu<br />
                <Box component="span" sx={{ color: 'secondary.main' }}>Mente.</Box>
              </Typography>
              <Typography variant="h6" color="text.secondary" sx={{ mb: 4, maxWidth: 500, fontWeight: 400, lineHeight: 1.7 }}>
                Más de 500 miembros activos transformando sus vidas con entrenadores certificados, equipos de última tecnología y programas personalizados.
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                <Button variant="contained" size="large" onClick={() => navigate('/register')} sx={{ px: 4, py: 1.5, fontSize: '1rem' }}>
                  Comenzar Gratis
                </Button>
                <Button variant="outlined" size="large" sx={{ px: 4, py: 1.5, borderColor: 'rgba(255,255,255,0.2)', color: 'white', '&:hover': { borderColor: 'primary.main' } }}>
                  Ver Planes
                </Button>
              </Box>
              <Box sx={{ display: 'flex', gap: 4, mt: 6 }}>
                {[{ value: '500+', label: 'Miembros Activos' }, { value: '15+', label: 'Entrenadores' }, { value: '5 Años', label: 'De Experiencia' }].map(stat => (
                  <Box key={stat.label}>
                    <Typography variant="h4" sx={{ color: 'primary.main', fontWeight: 800 }}>{stat.value}</Typography>
                    <Typography variant="caption" color="text.secondary">{stat.label}</Typography>
                  </Box>
                ))}
              </Box>
            </Grid>
            <Grid size={{ xs: 12, md: 5 }}>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {[
                  { icon: <FitnessCenterIcon />, title: 'Equipos de Clase Mundial', desc: 'Más de 200 equipos modernos disponibles' },
                  { icon: <PeopleIcon />, title: 'Entrenadores Certificados', desc: 'Equipo profesional con años de experiencia' },
                  { icon: <EmojiEventsIcon />, title: 'Resultados Garantizados', desc: 'Programas diseñados para tu objetivo' },
                ].map(item => (
                  <Card key={item.title} sx={{ p: 2, display: 'flex', gap: 2, alignItems: 'center', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,107,53,0.2)' }}>
                    <Box sx={{ p: 1.5, bgcolor: 'rgba(255,107,53,0.15)', borderRadius: 2, color: 'primary.main' }}>
                      {item.icon}
                    </Box>
                    <Box>
                      <Typography variant="subtitle2" fontWeight={700}>{item.title}</Typography>
                      <Typography variant="caption" color="text.secondary">{item.desc}</Typography>
                    </Box>
                  </Card>
                ))}
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* Plans */}
      <Box sx={{ py: 10, background: 'linear-gradient(180deg, #0A0A0A 0%, #0F0F0F 100%)' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Chip label="MEMBRESÍAS" sx={{ mb: 2, bgcolor: 'rgba(255,107,53,0.15)', color: 'primary.main', fontWeight: 700 }} />
            <Typography variant="h3" sx={{ mb: 2 }}>Planes Para Todos</Typography>
            <Typography color="text.secondary" sx={{ maxWidth: 500, mx: 'auto' }}>
              Elige el plan que mejor se adapte a tus objetivos y presupuesto
            </Typography>
          </Box>
          <Grid container spacing={3} justifyContent="center">
            {plans.map(plan => (
              <Grid key={plan.name} size={{ xs: 12, sm: 6, md: 4, lg: 2.4 }}>
                <Card sx={{
                  p: 3, height: '100%', position: 'relative', cursor: 'pointer',
                  border: plan.popular ? '2px solid #FF6B35' : '1px solid rgba(255,255,255,0.06)',
                  background: plan.popular ? 'linear-gradient(145deg, rgba(255,107,53,0.1), rgba(20,20,20,1))' : '#141414',
                  transition: 'transform 0.2s, box-shadow 0.2s',
                  '&:hover': { transform: 'translateY(-4px)', boxShadow: '0 12px 40px rgba(255,107,53,0.2)' },
                }}>
                  {plan.popular && (
                    <Chip label="MÁS POPULAR" size="small" sx={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', bgcolor: 'primary.main', color: 'white', fontWeight: 700, fontSize: '0.65rem' }} />
                  )}
                  <Typography variant="h6" fontWeight={700} gutterBottom>{plan.name}</Typography>
                  <Box sx={{ my: 2 }}>
                    <Typography variant="h4" sx={{ color: 'primary.main', fontWeight: 800 }}>$ {plan.price}</Typography>
                    <Typography variant="caption" color="text.secondary">{plan.period}</Typography>
                  </Box>
                  <Divider sx={{ my: 2 }} />
                  <List dense disablePadding>
                    {plan.features.map(f => (
                      <ListItem key={f} disablePadding sx={{ py: 0.3 }}>
                        <ListItemIcon sx={{ minWidth: 28 }}>
                          <CheckCircleIcon sx={{ fontSize: 16, color: 'secondary.main' }} />
                        </ListItemIcon>
                        <ListItemText primary={f} primaryTypographyProps={{ variant: 'caption', color: 'text.secondary' }} />
                      </ListItem>
                    ))}
                  </List>
                  <Button fullWidth variant={plan.popular ? 'contained' : 'outlined'} sx={{ mt: 3, borderColor: plan.popular ? undefined : 'rgba(255,255,255,0.2)', color: plan.popular ? 'white' : 'text.primary' }} onClick={() => navigate('/register')}>
                    Elegir Plan
                  </Button>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* Trainers */}
      <Box sx={{ py: 10, bgcolor: 'background.default' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Chip label="ENTRENADORES" sx={{ mb: 2, bgcolor: 'rgba(29,185,84,0.15)', color: 'secondary.main', fontWeight: 700 }} />
            <Typography variant="h3" sx={{ mb: 2 }}>Nuestro Equipo Elite</Typography>
            <Typography color="text.secondary">Entrenadores certificados comprometidos con tus resultados</Typography>
          </Box>
          <Grid container spacing={3}>
            {trainers.map(t => (
              <Grid key={t.name} size={{ xs: 12, sm: 6, md: 3 }}>
                <Card sx={{ p: 3, textAlign: 'center', transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
                  <Avatar sx={{ width: 80, height: 80, mx: 'auto', mb: 2, bgcolor: t.color, fontSize: '1.5rem', fontWeight: 700 }}>
                    {t.initials}
                  </Avatar>
                  <Typography variant="h6" fontWeight={700}>{t.name}</Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{t.specialty}</Typography>
                  <Box sx={{ display: 'flex', justifyContent: 'space-around' }}>
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, justifyContent: 'center' }}>
                        <StarIcon sx={{ fontSize: 14, color: '#FFB800' }} />
                        <Typography variant="body2" fontWeight={700}>{t.rating}</Typography>
                      </Box>
                      <Typography variant="caption" color="text.secondary">Rating</Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" fontWeight={700}>{t.clients}</Typography>
                      <Typography variant="caption" color="text.secondary">Clientes</Typography>
                    </Box>
                    <Box>
                      <Typography variant="body2" fontWeight={700}>{t.experience}</Typography>
                      <Typography variant="caption" color="text.secondary">Exp.</Typography>
                    </Box>
                  </Box>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* Testimonials */}
      <Box sx={{ py: 10, background: 'linear-gradient(180deg, #0A0A0A 0%, #0F0F0F 100%)' }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Chip label="TESTIMONIOS" sx={{ mb: 2, bgcolor: 'rgba(255,184,0,0.15)', color: '#FFB800', fontWeight: 700 }} />
            <Typography variant="h3">Lo Que Dicen Nuestros Miembros</Typography>
          </Box>
          <Grid container spacing={3}>
            {testimonials.map(t => (
              <Grid key={t.name} size={{ xs: 12, md: 4 }}>
                <Card sx={{ p: 3, height: '100%' }}>
                  <Box sx={{ display: 'flex', mb: 2 }}>
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <StarIcon key={i} sx={{ fontSize: 18, color: '#FFB800' }} />
                    ))}
                  </Box>
                  <Typography color="text.secondary" sx={{ mb: 3, lineHeight: 1.8, fontStyle: 'italic' }}>
                    "{t.text}"
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <Avatar sx={{ bgcolor: 'primary.main', fontWeight: 700 }}>{t.name[0]}</Avatar>
                    <Box>
                      <Typography variant="subtitle2" fontWeight={700}>{t.name}</Typography>
                      <Typography variant="caption" color="text.secondary">Miembro por {t.months}</Typography>
                    </Box>
                  </Box>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* Schedule */}
      <Box sx={{ py: 10, bgcolor: 'background.default' }}>
        <Container maxWidth="lg">
          <Grid container spacing={6} alignItems="center">
            <Grid size={{ xs: 12, md: 6 }}>
              <Chip label="HORARIOS" sx={{ mb: 2, bgcolor: 'rgba(33,150,243,0.15)', color: 'info.main', fontWeight: 700 }} />
              <Typography variant="h3" sx={{ mb: 3 }}>Siempre Abierto Para Ti</Typography>
              <Typography color="text.secondary" sx={{ mb: 4 }}>
                Tenemos horarios flexibles para que puedas entrenar cuando mejor te convenga.
              </Typography>
              {schedules.map(s => (
                <Box key={s.day} sx={{ display: 'flex', justifyContent: 'space-between', py: 1.5, borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <AccessTimeIcon sx={{ fontSize: 18, color: 'primary.main' }} />
                    <Typography fontWeight={600}>{s.day}</Typography>
                  </Box>
                  <Typography color="text.secondary">{s.hours}</Typography>
                </Box>
              ))}
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Card sx={{ p: 4, background: 'linear-gradient(135deg, rgba(255,107,53,0.1), rgba(20,20,20,1))', border: '1px solid rgba(255,107,53,0.2)' }}>
                <Typography variant="h5" fontWeight={700} sx={{ mb: 1 }}>¿Listo para empezar?</Typography>
                <Typography color="text.secondary" sx={{ mb: 3 }}>
                  Regístrate hoy y obtén tu primera semana gratis. Sin compromisos.
                </Typography>
                <Button fullWidth variant="contained" size="large" onClick={() => navigate('/register')} sx={{ py: 1.5 }}>
                  Comenzar Ahora — ¡Es Gratis!
                </Button>
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', textAlign: 'center', mt: 2 }}>
                  Sin tarjeta de crédito requerida
                </Typography>
              </Card>
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* Footer */}
      <Box sx={{ py: 6, borderTop: '1px solid rgba(255,255,255,0.06)', bgcolor: '#0D0D0D' }}>
        <Container maxWidth="lg">
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <LocalFireDepartmentIcon sx={{ color: 'primary.main' }} />
              <Typography variant="h6" fontWeight={800}>FitPro<span style={{ color: '#FF6B35' }}>Gym</span></Typography>
            </Box>
            <Typography variant="body2" color="text.secondary">© 2024 FitProGym. Todos los derechos reservados.</Typography>
            <Button variant="contained" size="small" onClick={() => navigate('/login')}>
              Panel de Administración
            </Button>
          </Box>
        </Container>
      </Box>
    </Box>
  );
}
