import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Alert from '@mui/material/Alert';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import Divider from '@mui/material/Divider';
import CircularProgress from '@mui/material/CircularProgress';
import EmailIcon from '@mui/icons-material/Email';
import LockIcon from '@mui/icons-material/Lock';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import LocalFireDepartmentIcon from '@mui/icons-material/LocalFireDepartment';
import { useAuth } from '../../context/AuthContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { signIn, refreshProfile } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const { error: err } = await signIn(email, password);
    if (err) {
      setError('Correo o contraseña incorrectos.');
      setLoading(false);
      return;
    }
    await refreshProfile();
    // profile state is stale here; re-read from supabase directly
    const { supabase } = await import('../../lib/supabase');
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data: prof } = await supabase.from('profiles').select('role').eq('id', user.id).maybeSingle();
      if (prof?.role === 'admin' || prof?.role === 'trainer') navigate('/admin');
      else navigate('/portal');
    } else {
      navigate('/portal');
    }
  };

  return (
    <Box sx={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0A0A0A 0%, #1A0A00 50%, #0A0A0A 100%)',
      '&::before': {
        content: '""',
        position: 'fixed',
        inset: 0,
        background: 'radial-gradient(ellipse at 30% 70%, rgba(255,107,53,0.12) 0%, transparent 60%)',
        pointerEvents: 'none',
      },
    }}>
      <Box sx={{ width: '100%', maxWidth: 420, px: 2, position: 'relative', zIndex: 1 }}>
        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1, mb: 1 }}>
            <LocalFireDepartmentIcon sx={{ color: 'primary.main', fontSize: 36 }} />
            <Typography variant="h4" fontWeight={800}>
              FitPro<span style={{ color: '#FF6B35' }}>Gym</span>
            </Typography>
          </Box>
          <Typography color="text.secondary">Bienvenido de vuelta</Typography>
        </Box>

        <Card sx={{ p: 4 }}>
          <Typography variant="h5" fontWeight={700} sx={{ mb: 0.5 }}>Iniciar Sesión</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>Ingresa tus credenciales para continuar</Typography>

          {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}

          <Box component="form" onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Correo electrónico"
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              sx={{ mb: 2 }}
              InputProps={{
                startAdornment: <InputAdornment position="start"><EmailIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment>,
              }}
            />
            <TextField
              fullWidth
              label="Contraseña"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              sx={{ mb: 3 }}
              InputProps={{
                startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment>,
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setShowPassword(!showPassword)}>
                      {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
            <Button type="submit" fullWidth variant="contained" size="large" disabled={loading} sx={{ py: 1.5, mb: 2 }}>
              {loading ? <CircularProgress size={22} color="inherit" /> : 'Ingresar'}
            </Button>
          </Box>

          <Divider sx={{ my: 2 }}>
            <Typography variant="caption" color="text.secondary">o</Typography>
          </Divider>

          <Typography variant="body2" color="text.secondary" textAlign="center">
            ¿No tienes cuenta?{' '}
            <Link to="/register" style={{ color: '#FF6B35', fontWeight: 600, textDecoration: 'none' }}>
              Regístrate aquí
            </Link>
          </Typography>

          <Box sx={{ mt: 3, p: 2, bgcolor: 'rgba(255,107,53,0.08)', borderRadius: 2, border: '1px solid rgba(255,107,53,0.2)' }}>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1, fontWeight: 600 }}>
              CREDENCIALES DE DEMO:
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
              Admin: admin@fitpro.com / admin123
            </Typography>
          </Box>
        </Card>

        <Box sx={{ textAlign: 'center', mt: 2 }}>
          <Link to="/" style={{ color: '#A0A0A0', textDecoration: 'none', fontSize: '0.875rem' }}>
            ← Volver al inicio
          </Link>
        </Box>
      </Box>
    </Box>
  );
}
