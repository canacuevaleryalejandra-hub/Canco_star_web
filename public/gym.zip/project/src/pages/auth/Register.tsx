import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Alert from '@mui/material/Alert';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import CircularProgress from '@mui/material/CircularProgress';
import MenuItem from '@mui/material/MenuItem';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import LockIcon from '@mui/icons-material/Lock';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import LocalFireDepartmentIcon from '@mui/icons-material/LocalFireDepartment';
import { useAuth } from '../../context/AuthContext';

export default function Register() {
  const [form, setForm] = useState({ fullName: '', email: '', password: '', confirm: '', role: 'client' });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const handleChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(prev => ({ ...prev, [field]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirm) { setError('Las contraseñas no coinciden.'); return; }
    if (form.password.length < 6) { setError('La contraseña debe tener al menos 6 caracteres.'); return; }
    setLoading(true);
    setError('');
    const { error: err } = await signUp(form.email, form.password, form.fullName, form.role as 'admin' | 'trainer' | 'client');
    if (err) { setError(err.message || 'Error al registrarse.'); setLoading(false); return; }
    navigate(form.role === 'client' ? '/portal' : '/admin');
  };

  return (
    <Box sx={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0A0A0A 0%, #0A1A00 50%, #0A0A0A 100%)',
      '&::before': {
        content: '""',
        position: 'fixed',
        inset: 0,
        background: 'radial-gradient(ellipse at 70% 30%, rgba(29,185,84,0.1) 0%, transparent 60%)',
        pointerEvents: 'none',
      },
    }}>
      <Box sx={{ width: '100%', maxWidth: 440, px: 2, position: 'relative', zIndex: 1 }}>
        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1, mb: 1 }}>
            <LocalFireDepartmentIcon sx={{ color: 'primary.main', fontSize: 36 }} />
            <Typography variant="h4" fontWeight={800}>
              FitPro<span style={{ color: '#FF6B35' }}>Gym</span>
            </Typography>
          </Box>
          <Typography color="text.secondary">Únete a nuestra comunidad</Typography>
        </Box>

        <Card sx={{ p: 4 }}>
          <Typography variant="h5" fontWeight={700} sx={{ mb: 0.5 }}>Crear Cuenta</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>Completa el formulario para registrarte</Typography>

          {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}

          <Box component="form" onSubmit={handleSubmit}>
            <TextField
              fullWidth label="Nombre completo" value={form.fullName}
              onChange={handleChange('fullName')} required sx={{ mb: 2 }}
              InputProps={{ startAdornment: <InputAdornment position="start"><PersonIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment> }}
            />
            <TextField
              fullWidth label="Correo electrónico" type="email" value={form.email}
              onChange={handleChange('email')} required sx={{ mb: 2 }}
              InputProps={{ startAdornment: <InputAdornment position="start"><EmailIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment> }}
            />
            <TextField
              fullWidth label="Contraseña" type={showPassword ? 'text' : 'password'}
              value={form.password} onChange={handleChange('password')} required sx={{ mb: 2 }}
              InputProps={{
                startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment>,
                endAdornment: <InputAdornment position="end"><IconButton size="small" onClick={() => setShowPassword(!showPassword)}>{showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}</IconButton></InputAdornment>,
              }}
            />
            <TextField
              fullWidth label="Confirmar contraseña" type={showPassword ? 'text' : 'password'}
              value={form.confirm} onChange={handleChange('confirm')} required sx={{ mb: 2 }}
              InputProps={{ startAdornment: <InputAdornment position="start"><LockIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment> }}
            />
            <TextField select fullWidth label="Tipo de cuenta" value={form.role} onChange={handleChange('role')} sx={{ mb: 3 }}>
              <MenuItem value="client">Cliente</MenuItem>
              <MenuItem value="trainer">Entrenador</MenuItem>
              <MenuItem value="admin">Administrador</MenuItem>
            </TextField>
            <Button type="submit" fullWidth variant="contained" size="large" disabled={loading} sx={{ py: 1.5 }}>
              {loading ? <CircularProgress size={22} color="inherit" /> : 'Crear Cuenta'}
            </Button>
          </Box>

          <Typography variant="body2" color="text.secondary" textAlign="center" sx={{ mt: 2 }}>
            ¿Ya tienes cuenta?{' '}
            <Link to="/login" style={{ color: '#FF6B35', fontWeight: 600, textDecoration: 'none' }}>
              Inicia sesión
            </Link>
          </Typography>
        </Card>

        <Box sx={{ textAlign: 'center', mt: 2 }}>
          <Link to="/" style={{ color: '#A0A0A0', textDecoration: 'none', fontSize: '0.875rem' }}>
            ← Volver al inicio
          </Link>
        </Box>
      </Box>
    </Box>
  );
}
