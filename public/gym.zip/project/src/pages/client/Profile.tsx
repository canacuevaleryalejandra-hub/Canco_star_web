import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import Chip from '@mui/material/Chip';
import LinearProgress from '@mui/material/LinearProgress';
import Skeleton from '@mui/material/Skeleton';
import Alert from '@mui/material/Alert';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import PaymentIcon from '@mui/icons-material/Payment';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { formatDate, getStatusColor, getStatusLabel, isMembershipExpired, isMembershipExpiringSoon } from '../../utils/helpers';
import type { Client } from '../../lib/supabase';
import { differenceInDays, parseISO } from 'date-fns';

export default function ClientProfile() {
  const { user, profile } = useAuth();
  const [client, setClient] = useState<Client | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase.from('clients').select('*, memberships(*), trainers(full_name, specialty)').eq('user_id', user.id).maybeSingle().then(({ data }) => {
      setClient(data as Client | null);
      setLoading(false);
    });
  }, [user]);

  const daysRemaining = client?.end_date
    ? Math.max(0, differenceInDays(parseISO(client.end_date), new Date()))
    : null;

  const membershipProgress = client?.start_date && client?.end_date
    ? Math.min(100, Math.max(0, ((differenceInDays(new Date(), parseISO(client.start_date)) / differenceInDays(parseISO(client.end_date), parseISO(client.start_date))) * 100)))
    : 0;

  if (loading) return (
    <Box>
      <Skeleton height={200} sx={{ borderRadius: 3 }} />
      <Grid container spacing={2} sx={{ mt: 2 }}>
        {[1, 2, 3].map(i => <Grid key={i} size={{ xs: 12, sm: 4 }}><Skeleton height={120} sx={{ borderRadius: 2 }} /></Grid>)}
      </Grid>
    </Box>
  );

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={800}>Mi Perfil</Typography>
        <Typography color="text.secondary">Bienvenido de vuelta, {profile?.full_name?.split(' ')[0]}</Typography>
      </Box>

      {!client && (
        <Alert severity="info" sx={{ mb: 3 }}>
          Tu cuenta aún no está vinculada a un perfil de cliente. Contacta al administrador.
        </Alert>
      )}

      {/* Profile Header */}
      <Card sx={{ p: 4, mb: 3, background: 'linear-gradient(135deg, rgba(255,107,53,0.1), rgba(20,20,20,1))', border: '1px solid rgba(255,107,53,0.2)' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 3, flexWrap: 'wrap' }}>
          <Avatar sx={{ width: 80, height: 80, bgcolor: 'primary.main', fontSize: '2rem', fontWeight: 800 }}>
            {(client?.first_name || profile?.full_name || '?')[0]}
          </Avatar>
          <Box sx={{ flex: 1 }}>
            <Typography variant="h5" fontWeight={800}>
              {client ? `${client.first_name} ${client.last_name}` : profile?.full_name || 'Cliente'}
            </Typography>
            <Typography color="text.secondary">{client?.email || user?.email}</Typography>
            {client && (
              <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
                <Chip label={getStatusLabel(client.status)} color={getStatusColor(client.status)} size="small" />
                {client.memberships?.name && <Chip label={client.memberships.name} size="small" sx={{ bgcolor: 'rgba(255,107,53,0.15)', color: 'primary.main' }} />}
              </Box>
            )}
          </Box>
        </Box>
      </Card>

      {/* Stats */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card sx={{ p: 3, textAlign: 'center' }}>
            <Box sx={{ p: 2, bgcolor: 'rgba(255,107,53,0.15)', borderRadius: '50%', width: 56, height: 56, display: 'flex', alignItems: 'center', justifyContent: 'center', mx: 'auto', mb: 2 }}>
              <CalendarMonthIcon sx={{ color: 'primary.main' }} />
            </Box>
            <Typography variant="h4" fontWeight={800} sx={{ color: 'primary.main' }}>
              {daysRemaining !== null ? daysRemaining : '-'}
            </Typography>
            <Typography variant="body2" color="text.secondary">Días restantes</Typography>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card sx={{ p: 3, textAlign: 'center' }}>
            <Box sx={{ p: 2, bgcolor: 'rgba(29,185,84,0.15)', borderRadius: '50%', width: 56, height: 56, display: 'flex', alignItems: 'center', justifyContent: 'center', mx: 'auto', mb: 2 }}>
              <FitnessCenterIcon sx={{ color: 'secondary.main' }} />
            </Box>
            <Typography variant="h4" fontWeight={800} sx={{ color: 'secondary.main' }}>
              {client?.trainers?.full_name ? '✓' : '-'}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {client?.trainers?.full_name || 'Sin entrenador'}
            </Typography>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card sx={{ p: 3, textAlign: 'center' }}>
            <Box sx={{ p: 2, bgcolor: 'rgba(33,150,243,0.15)', borderRadius: '50%', width: 56, height: 56, display: 'flex', alignItems: 'center', justifyContent: 'center', mx: 'auto', mb: 2 }}>
              <PaymentIcon sx={{ color: 'info.main' }} />
            </Box>
            <Typography variant="h4" fontWeight={800} sx={{ color: 'info.main' }}>
              $ {Number(client?.memberships?.price || 0).toLocaleString('es-CO')}
            </Typography>
            <Typography variant="body2" color="text.secondary">Valor membresía</Typography>
          </Card>
        </Grid>
      </Grid>

      {/* Membership Progress */}
      {client?.start_date && client?.end_date && (
        <Card sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
            <Typography variant="h6" fontWeight={700}>Membresía {client.memberships?.name}</Typography>
            {isMembershipExpiringSoon(client.end_date) && !isMembershipExpired(client.end_date) && (
              <Chip label="Vence pronto" color="warning" size="small" />
            )}
            {isMembershipExpired(client.end_date) && (
              <Chip label="Vencida" color="error" size="small" />
            )}
          </Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="caption" color="text.secondary">Inicio: {formatDate(client.start_date)}</Typography>
            <Typography variant="caption" color="text.secondary">Vence: {formatDate(client.end_date)}</Typography>
          </Box>
          <LinearProgress variant="determinate" value={membershipProgress} sx={{ mb: 1 }} />
          <Typography variant="caption" color="text.secondary">{Math.round(membershipProgress)}% del período completado</Typography>
        </Card>
      )}

      {/* Info */}
      {client && (
        <Card sx={{ p: 3 }}>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 3 }}>Información Personal</Typography>
          <Grid container spacing={2}>
            {[
              { label: 'Teléfono', value: client.phone || '-' },
              { label: 'Documento', value: client.document_number || '-' },
              { label: 'Fecha de nacimiento', value: formatDate(client.birth_date) },
              { label: 'Dirección', value: client.address || '-' },
              { label: 'Entrenador', value: client.trainers?.full_name || 'No asignado' },
              { label: 'Especialidad', value: client.trainers?.specialty || '-' },
            ].map(info => (
              <Grid key={info.label} size={{ xs: 12, sm: 6 }}>
                <Box>
                  <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'uppercase', fontWeight: 600, fontSize: '0.65rem', letterSpacing: '0.08em' }}>
                    {info.label}
                  </Typography>
                  <Typography variant="body2" fontWeight={500}>{info.value}</Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Card>
      )}
    </Box>
  );
}
