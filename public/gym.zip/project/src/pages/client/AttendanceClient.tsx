import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Chip from '@mui/material/Chip';
import Skeleton from '@mui/material/Skeleton';
import Grid from '@mui/material/Grid';
import EventNoteIcon from '@mui/icons-material/EventNote';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { formatDatetime } from '../../utils/helpers';
import type { Attendance } from '../../lib/supabase';

export default function ClientAttendance() {
  const { user } = useAuth();
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase.from('clients').select('id').eq('user_id', user.id).maybeSingle().then(({ data: client }) => {
      if (!client) { setLoading(false); return; }
      supabase.from('attendance').select('*').eq('client_id', client.id).order('check_in', { ascending: false }).then(({ data }) => {
        setAttendance((data || []) as Attendance[]);
        setLoading(false);
      });
    });
  }, [user]);

  const thisMonth = attendance.filter(a => {
    const d = new Date(a.check_in);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });

  const avgDuration = attendance.filter(a => a.check_out).reduce((acc, a, _, arr) => {
    const d = Math.round((new Date(a.check_out!).getTime() - new Date(a.check_in).getTime()) / 60000);
    return acc + d / arr.length;
  }, 0);

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={800}>Mi Asistencia</Typography>
        <Typography color="text.secondary">Historial de check-ins</Typography>
      </Box>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {[
          { title: 'Total Visitas', value: attendance.length, color: '#FF6B35', icon: <EventNoteIcon /> },
          { title: 'Este Mes', value: thisMonth.length, color: '#1DB954', icon: <CheckCircleIcon /> },
          { title: 'Tiempo Prom.', value: avgDuration > 0 ? `${Math.round(avgDuration)} min` : '-', color: '#2196F3', icon: <AccessTimeIcon /> },
        ].map(s => (
          <Grid key={s.title} size={{ xs: 12, sm: 4 }}>
            <Card sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.06em' }}>{s.title}</Typography>
                  <Typography variant="h4" fontWeight={800} sx={{ mt: 0.5 }}>{s.value}</Typography>
                </Box>
                <Box sx={{ p: 1.5, bgcolor: `${s.color}20`, borderRadius: 2, color: s.color }}>{s.icon}</Box>
              </Box>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Card>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Check-In</TableCell>
                <TableCell>Check-Out</TableCell>
                <TableCell>Duración</TableCell>
                <TableCell>Estado</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? Array.from({ length: 6 }).map((_, i) => (
                <TableRow key={i}>{Array.from({ length: 4 }).map((_, j) => <TableCell key={j}><Skeleton /></TableCell>)}</TableRow>
              )) : attendance.map(a => {
                const duration = a.check_out ? Math.round((new Date(a.check_out).getTime() - new Date(a.check_in).getTime()) / 60000) : null;
                return (
                  <TableRow key={a.id} hover>
                    <TableCell><Typography variant="body2">{formatDatetime(a.check_in)}</Typography></TableCell>
                    <TableCell><Typography variant="body2">{a.check_out ? formatDatetime(a.check_out) : '-'}</Typography></TableCell>
                    <TableCell><Typography variant="body2">{duration ? `${duration} min` : '-'}</Typography></TableCell>
                    <TableCell>
                      <Chip label={a.check_out ? 'Completado' : 'En gimnasio'} color={a.check_out ? 'default' : 'success'} size="small" />
                    </TableCell>
                  </TableRow>
                );
              })}
              {!loading && attendance.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} align="center" sx={{ py: 6 }}>
                    <EventNoteIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 1 }} />
                    <Typography color="text.secondary">No hay registros de asistencia</Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>
    </Box>
  );
}
