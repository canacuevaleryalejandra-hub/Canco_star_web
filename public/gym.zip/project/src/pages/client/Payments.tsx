import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Chip from '@mui/material/Chip';
import Skeleton from '@mui/material/Skeleton';
import PaymentIcon from '@mui/icons-material/Payment';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import Grid from '@mui/material/Grid';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { formatDate, getStatusColor, getStatusLabel, getPaymentMethodLabel } from '../../utils/helpers';
import type { Payment } from '../../lib/supabase';

const METHOD_ICONS: Record<string, string> = { cash: '💵', card: '💳', transfer: '🏦', nequi: '📱', daviplata: '📱' };

export default function ClientPayments() {
  const { user } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase.from('clients').select('id').eq('user_id', user.id).maybeSingle().then(({ data: client }) => {
      if (!client) { setLoading(false); return; }
      supabase.from('payments').select('*, memberships(name)').eq('client_id', client.id).order('created_at', { ascending: false }).then(({ data }) => {
        setPayments((data || []) as Payment[]);
        setLoading(false);
      });
    });
  }, [user]);

  const total = payments.filter(p => p.status === 'completed').reduce((s, p) => s + Number(p.amount), 0);

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={800}>Mis Pagos</Typography>
        <Typography color="text.secondary">Historial de pagos y facturas</Typography>
      </Box>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 6 }}>
          <Card sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.06em' }}>Total Pagado</Typography>
                <Typography variant="h4" fontWeight={800} sx={{ color: 'secondary.main', mt: 0.5 }}>$ {total.toLocaleString('es-CO')}</Typography>
              </Box>
              <Box sx={{ p: 1.5, bgcolor: 'rgba(29,185,84,0.15)', borderRadius: 2, color: 'secondary.main' }}><AttachMoneyIcon /></Box>
            </Box>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 6 }}>
          <Card sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.06em' }}>Transacciones</Typography>
                <Typography variant="h4" fontWeight={800} sx={{ mt: 0.5 }}>{payments.length}</Typography>
              </Box>
              <Box sx={{ p: 1.5, bgcolor: 'rgba(255,107,53,0.15)', borderRadius: 2, color: 'primary.main' }}><PaymentIcon /></Box>
            </Box>
          </Card>
        </Grid>
      </Grid>

      <Card>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Membresía</TableCell>
                <TableCell>Método</TableCell>
                <TableCell align="right">Monto</TableCell>
                <TableCell>Fecha</TableCell>
                <TableCell>Estado</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>{Array.from({ length: 5 }).map((_, j) => <TableCell key={j}><Skeleton /></TableCell>)}</TableRow>
              )) : payments.map(p => (
                <TableRow key={p.id} hover>
                  <TableCell><Typography variant="body2">{p.memberships?.name || 'Pago general'}</Typography></TableCell>
                  <TableCell><Chip label={`${METHOD_ICONS[p.payment_method]} ${getPaymentMethodLabel(p.payment_method)}`} size="small" sx={{ bgcolor: 'rgba(255,255,255,0.06)' }} /></TableCell>
                  <TableCell align="right"><Typography variant="body2" fontWeight={700} color="secondary.main">$ {Number(p.amount).toLocaleString('es-CO')}</Typography></TableCell>
                  <TableCell><Typography variant="body2">{formatDate(p.payment_date)}</Typography></TableCell>
                  <TableCell><Chip label={getStatusLabel(p.status)} color={getStatusColor(p.status)} size="small" /></TableCell>
                </TableRow>
              ))}
              {!loading && payments.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} align="center" sx={{ py: 6 }}>
                    <PaymentIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 1 }} />
                    <Typography color="text.secondary">No hay pagos registrados</Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>
    </Box>
  );
}
