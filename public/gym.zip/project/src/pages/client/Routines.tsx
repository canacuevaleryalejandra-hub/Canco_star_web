import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Chip from '@mui/material/Chip';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Skeleton from '@mui/material/Skeleton';
import Divider from '@mui/material/Divider';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import AssignmentIcon from '@mui/icons-material/Assignment';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { getDifficultyLabel } from '../../utils/helpers';
import type { Routine, Exercise } from '../../lib/supabase';

const DIFF_COLORS: Record<string, string> = { beginner: '#1DB954', intermediate: '#FFB800', advanced: '#FF6B35' };

export default function ClientRoutines() {
  const { user } = useAuth();
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase.from('clients').select('id').eq('user_id', user.id).maybeSingle().then(({ data: client }) => {
      if (!client) { setLoading(false); return; }
      supabase.from('routines').select('*, trainers(full_name, specialty), exercises(*)').eq('client_id', client.id).eq('is_active', true).then(({ data }) => {
        setRoutines((data || []) as Routine[]);
        setLoading(false);
      });
    });
  }, [user]);

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={800}>Mis Rutinas</Typography>
        <Typography color="text.secondary">Planes de entrenamiento asignados</Typography>
      </Box>

      {loading ? (
        <Box>{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} height={80} sx={{ mb: 1, borderRadius: 2 }} />)}</Box>
      ) : routines.length === 0 ? (
        <Card sx={{ p: 6, textAlign: 'center' }}>
          <AssignmentIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
          <Typography color="text.secondary">No tienes rutinas asignadas aún</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>Contacta a tu entrenador para comenzar</Typography>
        </Card>
      ) : (
        routines.map(r => (
          <Accordion key={r.id} sx={{ mb: 2, background: '#141414', border: '1px solid rgba(255,255,255,0.06)', '&:before': { display: 'none' } }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flex: 1, pr: 2 }}>
                <Box sx={{ p: 1, bgcolor: `${DIFF_COLORS[r.difficulty]}20`, borderRadius: 1.5 }}>
                  <FitnessCenterIcon sx={{ fontSize: 18, color: DIFF_COLORS[r.difficulty] }} />
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography fontWeight={700}>{r.title}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    {r.days_per_week} días/sem • {r.duration_weeks} semanas
                    {r.trainers?.full_name && ` • ${r.trainers.full_name}`}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Chip label={getDifficultyLabel(r.difficulty)} size="small" sx={{ bgcolor: `${DIFF_COLORS[r.difficulty]}20`, color: DIFF_COLORS[r.difficulty] }} />
                  <Chip label={`${r.exercises?.length || 0} ejercicios`} size="small" sx={{ bgcolor: 'rgba(255,255,255,0.06)' }} />
                </Box>
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <Divider sx={{ mb: 2 }} />
              {r.description && <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{r.description}</Typography>}
              {r.goal && (
                <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
                  <Typography variant="caption" color="text.secondary">Objetivo:</Typography>
                  <Typography variant="caption" fontWeight={600}>{r.goal}</Typography>
                </Box>
              )}
              {r.exercises && r.exercises.length > 0 ? (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Ejercicio</TableCell>
                        <TableCell>Músculo</TableCell>
                        <TableCell align="center">Series</TableCell>
                        <TableCell align="center">Reps</TableCell>
                        <TableCell align="center">Descanso</TableCell>
                        <TableCell align="center">Día</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {(r.exercises as Exercise[]).sort((a, b) => a.day_number - b.day_number || a.order_index - b.order_index).map(ex => (
                        <TableRow key={ex.id}>
                          <TableCell><Typography variant="body2" fontWeight={600}>{ex.name}</Typography></TableCell>
                          <TableCell><Chip label={ex.muscle_group || '-'} size="small" sx={{ bgcolor: 'rgba(255,255,255,0.06)' }} /></TableCell>
                          <TableCell align="center"><Typography variant="body2">{ex.sets}</Typography></TableCell>
                          <TableCell align="center"><Typography variant="body2">{ex.reps}</Typography></TableCell>
                          <TableCell align="center"><Typography variant="body2">{ex.rest_seconds}s</Typography></TableCell>
                          <TableCell align="center"><Chip label={`Día ${ex.day_number}`} size="small" sx={{ bgcolor: 'rgba(29,185,84,0.1)', color: 'secondary.main' }} /></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              ) : (
                <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>No hay ejercicios asignados</Typography>
              )}
            </AccordionDetails>
          </Accordion>
        ))
      )}
    </Box>
  );
}
