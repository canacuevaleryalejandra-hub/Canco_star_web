import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import Chip from '@mui/material/Chip';
import LinearProgress from '@mui/material/LinearProgress';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Skeleton from '@mui/material/Skeleton';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import PeopleIcon from '@mui/icons-material/People';
import CardMembershipIcon from '@mui/icons-material/CardMembership';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import WarningIcon from '@mui/icons-material/Warning';
import CheckInIcon from '@mui/icons-material/HowToReg';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { supabase } from '../../lib/supabase';
import { formatCurrency, formatDate, getStatusColor, getStatusLabel } from '../../utils/helpers';
import type { Client, Payment } from '../../lib/supabase';
import { useNavigate } from 'react-router-dom';

interface Stats {
  totalClients: number;
  activeClients: number;
  monthlyRevenue: number;
  expiredMemberships: number;
  todayAttendance: number;
}

const revenueData = [
  { mes: 'Ene', ingresos: 2800000 },
  { mes: 'Feb', ingresos: 3200000 },
  { mes: 'Mar', ingresos: 2900000 },
  { mes: 'Abr', ingresos: 3800000 },
  { mes: 'May', ingresos: 4100000 },
  { mes: 'Jun', ingresos: 3600000 },
  { mes: 'Jul', ingresos: 4500000 },
  { mes: 'Ago', ingresos: 5200000 },
];

const membershipDistribution = [
  { name: 'Mensual', value: 45, color: '#FF6B35' },
  { name: 'Trimestral', value: 25, color: '#1DB954' },
  { name: 'Anual', value: 20, color: '#2196F3' },
  { name: 'Otros', value: 10, color: '#FFB800' },
];

const attendanceData = [
  { dia: 'Lun', asistencias: 38 },
  { dia: 'Mar', asistencias: 45 },
  { dia: 'Mié', asistencias: 52 },
  { dia: 'Jue', asistencias: 41 },
  { dia: 'Vie', asistencias: 48 },
  { dia: 'Sáb', asistencias: 35 },
  { dia: 'Dom', asistencias: 22 },
];

function StatCard({ title, value, subtitle, icon, color, loading }: {
  title: string; value: string | number; subtitle?: string; icon: React.ReactNode; color: string; loading?: boolean;
}) {
  return (
    <Card sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1, fontWeight: 600, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.06em' }}>{title}</Typography>
          {loading ? <Skeleton width={100} height={40} /> : (
            <Typography variant="h4" fontWeight={800}>{value}</Typography>
          )}
          {subtitle && <Typography variant="caption" color="text.secondary">{subtitle}</Typography>}
        </Box>
        <Box sx={{ p: 1.5, bgcolor: `${color}20`, borderRadius: 2, color }}>
          {icon}
        </Box>
      </Box>
      {!loading && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 2 }}>
          <ArrowUpwardIcon sx={{ fontSize: 14, color: 'secondary.main' }} />
          <Typography variant="caption" color="secondary.main" fontWeight={600}>+12% </Typography>
          <Typography variant="caption" color="text.secondary">vs. mes anterior</Typography>
        </Box>
      )}
    </Card>
  );
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({ totalClients: 0, activeClients: 0, monthlyRevenue: 0, expiredMemberships: 0, todayAttendance: 0 });
  const [recentPayments, setRecentPayments] = useState<Payment[]>([]);
  const [recentClients, setRecentClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const load = async () => {
      const [clientsRes, paymentsRes, attendanceRes] = await Promise.all([
        supabase.from('clients').select('*, memberships(name, price)'),
        supabase.from('payments').select('*, clients(first_name, last_name), memberships(name)').order('created_at', { ascending: false }).limit(5),
        supabase.from('attendance').select('id', { count: 'exact' }).gte('check_in', new Date().toISOString().split('T')[0]),
      ]);

      const clients = (clientsRes.data || []) as Client[];
      const payments = (paymentsRes.data || []) as Payment[];
      const today = new Date().toISOString().split('T')[0];

      setStats({
        totalClients: clients.length,
        activeClients: clients.filter(c => c.status === 'active').length,
        monthlyRevenue: payments.reduce((sum, p) => sum + Number(p.amount), 0),
        expiredMemberships: clients.filter(c => c.end_date && c.end_date < today).length,
        todayAttendance: attendanceRes.count || 0,
      });
      setRecentPayments(payments);
      setRecentClients(clients.slice(0, 5));
      setLoading(false);
    };
    load();
  }, []);

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={800}>Dashboard</Typography>
        <Typography color="text.secondary">Resumen general del gimnasio</Typography>
      </Box>

      {/* Stats */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {[
          { title: 'Total Clientes', value: stats.totalClients, icon: <PeopleIcon />, color: '#2196F3', subtitle: 'registrados' },
          { title: 'Clientes Activos', value: stats.activeClients, icon: <CheckInIcon />, color: '#1DB954', subtitle: 'con membresía vigente' },
          { title: 'Ingresos del Mes', value: formatCurrency(stats.monthlyRevenue, '$'), icon: <AttachMoneyIcon />, color: '#FF6B35', subtitle: 'pagos recientes' },
          { title: 'Membresías Vencidas', value: stats.expiredMemberships, icon: <WarningIcon />, color: '#FFB800', subtitle: 'requieren atención' },
          { title: 'Asistencia Hoy', value: stats.todayAttendance, icon: <CardMembershipIcon />, color: '#9C27B0', subtitle: 'check-ins registrados' },
        ].map(s => (
          <Grid key={s.title} size={{ xs: 12, sm: 6, lg: 2.4 }}>
            <StatCard {...s} loading={loading} />
          </Grid>
        ))}
      </Grid>

      {/* Charts Row 1 */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 8 }}>
          <Card sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={700} sx={{ mb: 3 }}>Ingresos Mensuales</Typography>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorIngresos" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF6B35" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#FF6B35" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="mes" tick={{ fill: '#A0A0A0', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#A0A0A0', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000000).toFixed(1)}M`} />
                <Tooltip
                  contentStyle={{ background: '#1A1A1A', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}
                  labelStyle={{ color: '#fff' }}
                  formatter={(v: unknown) => [`$ ${(v as number).toLocaleString('es-CO')}`, 'Ingresos']}
                />
                <Area type="monotone" dataKey="ingresos" stroke="#FF6B35" strokeWidth={2} fill="url(#colorIngresos)" />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <Card sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={700} sx={{ mb: 3 }}>Distribución de Membresías</Typography>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={membershipDistribution} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">
                  {membershipDistribution.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#1A1A1A', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }} />
              </PieChart>
            </ResponsiveContainer>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {membershipDistribution.map(m => (
                <Box key={m.name} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: m.color }} />
                    <Typography variant="caption">{m.name}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <LinearProgress variant="determinate" value={m.value} sx={{ width: 60, bgcolor: 'rgba(255,255,255,0.06)', '& .MuiLinearProgress-bar': { background: m.color } }} />
                    <Typography variant="caption" fontWeight={700}>{m.value}%</Typography>
                  </Box>
                </Box>
              ))}
            </Box>
          </Card>
        </Grid>
      </Grid>

      {/* Charts Row 2 + Tables */}
      <Grid container spacing={3}>
        <Grid size={{ xs: 12, md: 5 }}>
          <Card sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={700} sx={{ mb: 3 }}>Asistencia Semanal</Typography>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={attendanceData} barSize={24}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="dia" tick={{ fill: '#A0A0A0', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#A0A0A0', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: '#1A1A1A', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }} />
                <Bar dataKey="asistencias" fill="#1DB954" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 7 }}>
          <Card sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6" fontWeight={700}>Pagos Recientes</Typography>
              <Button size="small" onClick={() => navigate('/admin/payments')} sx={{ color: 'primary.main' }}>Ver todos</Button>
            </Box>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Cliente</TableCell>
                    <TableCell>Membresía</TableCell>
                    <TableCell align="right">Monto</TableCell>
                    <TableCell>Fecha</TableCell>
                    <TableCell>Estado</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 5 }).map((_, j) => <TableCell key={j}><Skeleton /></TableCell>)}
                    </TableRow>
                  )) : recentPayments.map(p => (
                    <TableRow key={p.id} hover>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Avatar sx={{ width: 28, height: 28, fontSize: '0.75rem', bgcolor: 'primary.main' }}>
                            {p.clients?.first_name?.[0]}
                          </Avatar>
                          <Typography variant="body2">{p.clients?.first_name} {p.clients?.last_name}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell><Typography variant="body2">{p.memberships?.name || '-'}</Typography></TableCell>
                      <TableCell align="right"><Typography variant="body2" fontWeight={700} color="secondary.main">$ {Number(p.amount).toLocaleString('es-CO')}</Typography></TableCell>
                      <TableCell><Typography variant="body2">{formatDate(p.payment_date)}</Typography></TableCell>
                      <TableCell><Chip label={getStatusLabel(p.status)} color={getStatusColor(p.status)} size="small" /></TableCell>
                    </TableRow>
                  ))}
                  {!loading && recentPayments.length === 0 && (
                    <TableRow><TableCell colSpan={5} align="center"><Typography color="text.secondary" variant="body2" sx={{ py: 2 }}>No hay pagos registrados</Typography></TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Card>
        </Grid>

        {/* Recent Clients */}
        <Grid size={{ xs: 12 }}>
          <Card sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6" fontWeight={700}>Últimos Clientes</Typography>
              <Button size="small" onClick={() => navigate('/admin/clients')} sx={{ color: 'primary.main' }}>Ver todos</Button>
            </Box>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Cliente</TableCell>
                    <TableCell>Correo</TableCell>
                    <TableCell>Membresía</TableCell>
                    <TableCell>Vencimiento</TableCell>
                    <TableCell>Estado</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>{Array.from({ length: 5 }).map((_, j) => <TableCell key={j}><Skeleton /></TableCell>)}</TableRow>
                  )) : recentClients.map(c => (
                    <TableRow key={c.id} hover sx={{ cursor: 'pointer' }} onClick={() => navigate('/admin/clients')}>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                          <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.main', fontWeight: 700, fontSize: '0.8rem' }}>
                            {c.first_name[0]}
                          </Avatar>
                          <Typography variant="body2" fontWeight={600}>{c.first_name} {c.last_name}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell><Typography variant="body2" color="text.secondary">{c.email}</Typography></TableCell>
                      <TableCell><Typography variant="body2">{c.memberships?.name || '-'}</Typography></TableCell>
                      <TableCell><Typography variant="body2">{formatDate(c.end_date)}</Typography></TableCell>
                      <TableCell><Chip label={getStatusLabel(c.status)} color={getStatusColor(c.status)} size="small" /></TableCell>
                    </TableRow>
                  ))}
                  {!loading && recentClients.length === 0 && (
                    <TableRow><TableCell colSpan={5} align="center"><Typography color="text.secondary" variant="body2" sx={{ py: 2 }}>No hay clientes registrados</Typography></TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
