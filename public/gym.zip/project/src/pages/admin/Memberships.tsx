import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Chip from '@mui/material/Chip';
import IconButton from '@mui/material/IconButton';
import Switch from '@mui/material/Switch';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import Tooltip from '@mui/material/Tooltip';
import Skeleton from '@mui/material/Skeleton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CardMembershipIcon from '@mui/icons-material/CardMembership';
import { supabase } from '../../lib/supabase';
import type { Membership } from '../../lib/supabase';

const EMPTY_FORM = {
  name: '', duration_days: 30, price: 0, description: '',
  features: [''], is_active: true,
};

const DURATION_LABELS: Record<number, string> = {
  1: 'Diario', 7: 'Semanal', 30: 'Mensual', 90: 'Trimestral', 180: 'Semestral', 365: 'Anual',
};

export default function MembershipsPage() {
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editId, setEditId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    const { data } = await supabase.from('memberships').select('*').order('duration_days');
    setMemberships((data || []) as Membership[]);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const openNew = () => { setForm(EMPTY_FORM); setEditId(null); setError(''); setDialogOpen(true); };
  const openEdit = (m: Membership) => {
    setForm({ name: m.name, duration_days: m.duration_days, price: m.price, description: m.description, features: m.features.length ? m.features : [''], is_active: m.is_active });
    setEditId(m.id);
    setError('');
    setDialogOpen(true);
  };

  const handleToggleActive = async (m: Membership) => {
    await supabase.from('memberships').update({ is_active: !m.is_active }).eq('id', m.id);
    fetchData();
  };

  const handleSave = async () => {
    if (!form.name || !form.price) { setError('Nombre y precio son requeridos.'); return; }
    setSaving(true);
    setError('');
    const payload = { ...form, features: form.features.filter(f => f.trim()), price: Number(form.price), duration_days: Number(form.duration_days) };
    const { error: err } = editId
      ? await supabase.from('memberships').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editId)
      : await supabase.from('memberships').insert(payload);
    if (err) { setError(err.message); setSaving(false); return; }
    await fetchData();
    setDialogOpen(false);
    setSaving(false);
  };

  const updateFeature = (i: number, val: string) => {
    setForm(prev => { const f = [...prev.features]; f[i] = val; return { ...prev, features: f }; });
  };
  const addFeature = () => setForm(prev => ({ ...prev, features: [...prev.features, ''] }));
  const removeFeature = (i: number) => setForm(prev => ({ ...prev, features: prev.features.filter((_, idx) => idx !== i) }));

  const getCardColor = (days: number) => {
    if (days <= 1) return '#FFB800';
    if (days <= 7) return '#2196F3';
    if (days <= 30) return '#FF6B35';
    if (days <= 90) return '#9C27B0';
    return '#1DB954';
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Membresías</Typography>
          <Typography color="text.secondary">{memberships.length} planes disponibles</Typography>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={openNew}>Nueva Membresía</Button>
      </Box>

      <Grid container spacing={3}>
        {loading ? Array.from({ length: 5 }).map((_, i) => (
          <Grid key={i} size={{ xs: 12, sm: 6, md: 4 }}>
            <Card sx={{ p: 3 }}><Skeleton height={200} /></Card>
          </Grid>
        )) : memberships.map(m => {
          const color = getCardColor(m.duration_days);
          return (
            <Grid key={m.id} size={{ xs: 12, sm: 6, md: 4 }}>
              <Card sx={{
                p: 3, position: 'relative', overflow: 'visible',
                border: `1px solid ${color}30`,
                '&:hover': { boxShadow: `0 8px 30px ${color}20` },
                transition: 'box-shadow 0.2s',
                opacity: m.is_active ? 1 : 0.6,
              }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                  <Box sx={{ p: 1.5, bgcolor: `${color}20`, borderRadius: 2 }}>
                    <CardMembershipIcon sx={{ color }} />
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Chip label={m.is_active ? 'Activo' : 'Inactivo'} color={m.is_active ? 'success' : 'default'} size="small" />
                    <Tooltip title="Editar">
                      <IconButton size="small" onClick={() => openEdit(m)}><EditIcon fontSize="small" /></IconButton>
                    </Tooltip>
                  </Box>
                </Box>
                <Typography variant="h5" fontWeight={800}>{m.name}</Typography>
                <Typography variant="caption" color="text.secondary">{m.duration_days} días — {DURATION_LABELS[m.duration_days] || `${m.duration_days} días`}</Typography>
                <Typography variant="h4" sx={{ color, fontWeight: 800, my: 2 }}>
                  $ {Number(m.price).toLocaleString('es-CO')}
                </Typography>
                {m.description && (
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{m.description}</Typography>
                )}
                <List dense disablePadding>
                  {m.features.map((f, i) => (
                    <ListItem key={i} disablePadding sx={{ py: 0.3 }}>
                      <ListItemIcon sx={{ minWidth: 24 }}><CheckCircleIcon sx={{ fontSize: 14, color: 'secondary.main' }} /></ListItemIcon>
                      <ListItemText primary={f} primaryTypographyProps={{ variant: 'caption', color: 'text.secondary' }} />
                    </ListItem>
                  ))}
                </List>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 2, pt: 2, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                  <Typography variant="caption" color="text.secondary">Activo</Typography>
                  <Switch checked={m.is_active} size="small" onChange={() => handleToggleActive(m)} color="success" />
                </Box>
              </Card>
            </Grid>
          );
        })}
      </Grid>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editId ? 'Editar Membresía' : 'Nueva Membresía'}</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Nombre *" value={form.name} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField select fullWidth label="Duración" value={form.duration_days} onChange={e => setForm(prev => ({ ...prev, duration_days: Number(e.target.value) }))}>
                {[1, 7, 30, 90, 180, 365].map(d => <MenuItem key={d} value={d}>{DURATION_LABELS[d] || `${d} días`}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField fullWidth label="Precio *" type="number" value={form.price} onChange={e => setForm(prev => ({ ...prev, price: Number(e.target.value) }))} InputProps={{ startAdornment: <Box component="span" sx={{ mr: 1, color: 'text.secondary' }}>$</Box> }} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Descripción" value={form.description} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Características</Typography>
              {form.features.map((f, i) => (
                <Box key={i} sx={{ display: 'flex', gap: 1, mb: 1 }}>
                  <TextField fullWidth size="small" placeholder={`Característica ${i + 1}`} value={f} onChange={e => updateFeature(i, e.target.value)} />
                  <Button size="small" color="error" onClick={() => removeFeature(i)} sx={{ minWidth: 40 }}>✕</Button>
                </Box>
              ))}
              <Button size="small" onClick={addFeature} startIcon={<AddIcon />} sx={{ color: 'text.secondary' }}>Agregar característica</Button>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setDialogOpen(false)} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.primary' }}>Cancelar</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Guardar'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
