import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import InputAdornment from '@mui/material/InputAdornment';
import SettingsIcon from '@mui/icons-material/Settings';
import BusinessIcon from '@mui/icons-material/Business';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import { supabase } from '../../lib/supabase';
import type { GymSettings } from '../../lib/supabase';

export default function SettingsPage() {
  const [settings, setSettings] = useState<Partial<GymSettings>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    supabase.from('gym_settings').select('*').maybeSingle().then(({ data }) => {
      if (data) setSettings(data as GymSettings);
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setError('');
    setSuccess(false);
    const { error: err } = settings.id
      ? await supabase.from('gym_settings').update({ ...settings, updated_at: new Date().toISOString() }).eq('id', settings.id)
      : await supabase.from('gym_settings').insert(settings);
    if (err) { setError(err.message); setSaving(false); return; }
    setSuccess(true);
    setSaving(false);
    setTimeout(() => setSuccess(false), 3000);
  };

  const update = (field: keyof GymSettings) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setSettings(prev => ({ ...prev, [field]: e.target.value }));

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', p: 6 }}><CircularProgress /></Box>;

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Configuración</Typography>
          <Typography color="text.secondary">Administra la información del gimnasio</Typography>
        </Box>
        <Button variant="contained" onClick={handleSave} disabled={saving}>
          {saving ? <CircularProgress size={20} color="inherit" /> : 'Guardar Cambios'}
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 3 }}>Configuración guardada exitosamente</Alert>}

      <Grid container spacing={3}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
              <Box sx={{ p: 1, bgcolor: 'rgba(255,107,53,0.15)', borderRadius: 1.5 }}>
                <BusinessIcon sx={{ color: 'primary.main', fontSize: 20 }} />
              </Box>
              <Typography variant="h6" fontWeight={700}>Información General</Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth label="Nombre del Gimnasio" value={settings.gym_name || ''} onChange={update('gym_name')} />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth label="Eslogan" value={settings.slogan || ''} onChange={update('slogan')} />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth label="Dirección" value={settings.address || ''} onChange={update('address')} />
              </Grid>
              <Grid size={{ xs: 6 }}>
                <TextField fullWidth label="Teléfono" value={settings.phone || ''} onChange={update('phone')}
                  InputProps={{ startAdornment: <InputAdornment position="start"><PhoneIcon sx={{ fontSize: 16, color: 'text.secondary' }} /></InputAdornment> }} />
              </Grid>
              <Grid size={{ xs: 6 }}>
                <TextField fullWidth label="Correo" type="email" value={settings.email || ''} onChange={update('email')}
                  InputProps={{ startAdornment: <InputAdornment position="start"><EmailIcon sx={{ fontSize: 16, color: 'text.secondary' }} /></InputAdornment> }} />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth label="Sitio web" value={settings.website || ''} onChange={update('website')} />
              </Grid>
            </Grid>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <Card sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
              <Box sx={{ p: 1, bgcolor: 'rgba(29,185,84,0.15)', borderRadius: 1.5 }}>
                <SettingsIcon sx={{ color: 'secondary.main', fontSize: 20 }} />
              </Box>
              <Typography variant="h6" fontWeight={700}>Redes Sociales</Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth label="Facebook" value={settings.facebook || ''} onChange={update('facebook')}
                  InputProps={{ startAdornment: <InputAdornment position="start"><Typography variant="caption" color="text.secondary">fb.com/</Typography></InputAdornment> }} />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth label="Instagram" value={settings.instagram || ''} onChange={update('instagram')}
                  InputProps={{ startAdornment: <InputAdornment position="start"><Typography variant="caption" color="text.secondary">@</Typography></InputAdornment> }} />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth label="Twitter / X" value={settings.twitter || ''} onChange={update('twitter')}
                  InputProps={{ startAdornment: <InputAdornment position="start"><Typography variant="caption" color="text.secondary">@</Typography></InputAdornment> }} />
              </Grid>
            </Grid>
          </Card>

          <Card sx={{ p: 3, mt: 3 }}>
            <Typography variant="h6" fontWeight={700} sx={{ mb: 3 }}>Configuración Financiera</Typography>
            <Grid container spacing={2}>
              <Grid size={{ xs: 6 }}>
                <TextField fullWidth label="Moneda" value={settings.currency || 'COP'} onChange={update('currency')} />
              </Grid>
              <Grid size={{ xs: 6 }}>
                <TextField fullWidth label="Símbolo" value={settings.currency_symbol || '$'} onChange={update('currency_symbol')} />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth label="Impuesto (%)" type="number" value={settings.tax_rate || 0} onChange={update('tax_rate')} />
              </Grid>
            </Grid>
          </Card>

          <Card sx={{ p: 3, mt: 3 }}>
            <Typography variant="h6" fontWeight={700} sx={{ mb: 3 }}>Horarios del Gimnasio</Typography>
            <Grid container spacing={2}>
              <Grid size={{ xs: 6 }}>
                <TextField fullWidth label="Apertura" type="time" value={settings.opening_time || '06:00'} onChange={update('opening_time')} InputLabelProps={{ shrink: true }} />
              </Grid>
              <Grid size={{ xs: 6 }}>
                <TextField fullWidth label="Cierre" type="time" value={settings.closing_time || '22:00'} onChange={update('closing_time')} InputLabelProps={{ shrink: true }} />
              </Grid>
            </Grid>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
