import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Avatar from '@mui/material/Avatar';
import Chip from '@mui/material/Chip';
import Skeleton from '@mui/material/Skeleton';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import InputAdornment from '@mui/material/InputAdornment';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import CheckIcon from '@mui/icons-material/Check';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import EventNoteIcon from '@mui/icons-material/EventNote';
import { supabase } from '../../lib/supabase';
import { formatDatetime } from '../../utils/helpers';
import type { Attendance, Client } from '../../lib/supabase';

export default function AttendancePage() {
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState(new Date().toISOString().split('T')[0]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    const [attendanceRes, clientsRes] = await Promise.all([
      supabase.from('attendance')
        .select('*, clients(id, first_name, last_name, email, memberships(name))')
        .order('check_in', { ascending: false })
        .limit(100),
      supabase.from('clients').select('id, first_name, last_name, email, status, memberships(name)').eq('status', 'active'),
    ]);
    setAttendance((attendanceRes.data || []) as Attendance[]);
    setClients((clientsRes.data || []) as unknown as Client[]);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const filtered = attendance.filter(a => {
    const q = search.toLowerCase();
    const name = `${a.clients?.first_name || ''} ${a.clients?.last_name || ''}`.toLowerCase();
    const matchSearch = !q || name.includes(q);
    const matchDate = !dateFilter || a.check_in.startsWith(dateFilter);
    return matchSearch && matchDate;
  });

  const todayCount = attendance.filter(a => a.check_in.startsWith(new Date().toISOString().split('T')[0])).length;

  const handleCheckIn = async () => {
    if (!selectedClient) { setError('Selecciona un cliente.'); return; }
    const existing = attendance.find(a => a.client_id === selectedClient && a.check_in.startsWith(new Date().toISOString().split('T')[0]));
    if (existing) { setError('Este cliente ya tiene check-in registrado hoy.'); return; }
    setSaving(true);
    setError('');
    const { error: err } = await supabase.from('attendance').insert({ client_id: selectedClient, check_in: new Date().toISOString() });
    if (err) { setError(err.message); setSaving(false); return; }
    await fetchData();
    setDialogOpen(false);
    setSelectedClient('');
    setSaving(false);
  };

  const handleCheckOut = async (id: string) => {
    await supabase.from('attendance').update({ check_out: new Date().toISOString() }).eq('id', id);
    fetchData();
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Asistencia</Typography>
          <Typography color="text.secondary">{todayCount} check-ins hoy</Typography>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => { setSelectedClient(''); setError(''); setDialogOpen(true); }}>
          Registrar Check-In
        </Button>
      </Box>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {[
          { title: 'Asistencias Hoy', value: todayCount, color: '#1DB954', icon: <CheckIcon /> },
          { title: 'Esta Semana', value: attendance.filter(a => { const d = new Date(a.check_in); const now = new Date(); const diff = (now.getTime() - d.getTime()) / 86400000; return diff <= 7; }).length, color: '#FF6B35', icon: <AccessTimeIcon /> },
          { title: 'Total Registros', value: attendance.length, color: '#2196F3', icon: <EventNoteIcon /> },
        ].map(s => (
          <Grid key={s.title} size={{ xs: 12, sm: 4 }}>
            <Card sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.06em' }}>{s.title}</Typography>
                  <Typography variant="h4" fontWeight={800} sx={{ mt: 0.5 }}>{s.value}</Typography>
                </Box>
                <Box sx={{ p: 1.5, bgcolor: `${s.color}20`, borderRadius: 2, color: s.color }}>{s.icon}</Box>
              </Box>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 5 }}>
          <TextField fullWidth placeholder="Buscar por cliente..." value={search} onChange={e => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment> }} />
        </Grid>
        <Grid size={{ xs: 12, sm: 3 }}>
          <TextField fullWidth type="date" label="Fecha" value={dateFilter} onChange={e => setDateFilter(e.target.value)} InputLabelProps={{ shrink: true }} />
        </Grid>
        <Grid size={{ xs: 12, sm: 2 }}>
          <Button fullWidth variant="outlined" sx={{ height: '100%', borderColor: 'rgba(255,255,255,0.2)', color: 'text.secondary' }} onClick={() => setDateFilter('')}>
            Ver Todo
          </Button>
        </Grid>
      </Grid>

      <Card>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Cliente</TableCell>
                <TableCell>Membresía</TableCell>
                <TableCell>Check-In</TableCell>
                <TableCell>Check-Out</TableCell>
                <TableCell>Duración</TableCell>
                <TableCell align="center">Acción</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? Array.from({ length: 6 }).map((_, i) => (
                <TableRow key={i}>{Array.from({ length: 6 }).map((_, j) => <TableCell key={j}><Skeleton /></TableCell>)}</TableRow>
              )) : filtered.map(a => {
                const duration = a.check_out
                  ? Math.round((new Date(a.check_out).getTime() - new Date(a.check_in).getTime()) / 60000)
                  : null;
                return (
                  <TableRow key={a.id} hover>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Avatar sx={{ width: 32, height: 32, bgcolor: 'secondary.main', fontWeight: 700, fontSize: '0.8rem' }}>
                          {a.clients?.first_name?.[0]}
                        </Avatar>
                        <Typography variant="body2" fontWeight={600}>{a.clients?.first_name} {a.clients?.last_name}</Typography>
                      </Box>
                    </TableCell>
                    <TableCell><Typography variant="body2">{a.clients?.memberships?.name || '-'}</Typography></TableCell>
                    <TableCell><Typography variant="body2">{formatDatetime(a.check_in)}</Typography></TableCell>
                    <TableCell><Typography variant="body2">{a.check_out ? formatDatetime(a.check_out) : <Chip label="En gimnasio" color="success" size="small" />}</Typography></TableCell>
                    <TableCell><Typography variant="body2">{duration ? `${duration} min` : '-'}</Typography></TableCell>
                    <TableCell align="center">
                      {!a.check_out && (
                        <Tooltip title="Registrar salida">
                          <IconButton size="small" color="primary" onClick={() => handleCheckOut(a.id)}>
                            <CheckIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
              {!loading && filtered.length === 0 && (
                <TableRow><TableCell colSpan={6} align="center" sx={{ py: 6 }}><Typography color="text.secondary">No hay registros de asistencia</Typography></TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle>Registrar Check-In</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <TextField select fullWidth label="Cliente" value={selectedClient} onChange={e => setSelectedClient(e.target.value)} sx={{ mt: 1 }}>
            {clients.map(c => (
              <MenuItem key={c.id} value={c.id}>
                {c.first_name} {c.last_name}
                {c.memberships?.name && <Typography component="span" variant="caption" color="text.secondary"> — {c.memberships.name}</Typography>}
              </MenuItem>
            ))}
          </TextField>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setDialogOpen(false)} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.primary' }}>Cancelar</Button>
          <Button variant="contained" onClick={handleCheckIn} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Check-In'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
