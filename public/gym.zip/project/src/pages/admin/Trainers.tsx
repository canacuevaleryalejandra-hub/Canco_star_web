import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Avatar from '@mui/material/Avatar';
import Chip from '@mui/material/Chip';
import IconButton from '@mui/material/IconButton';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import Tooltip from '@mui/material/Tooltip';
import Switch from '@mui/material/Switch';
import Skeleton from '@mui/material/Skeleton';
import MenuItem from '@mui/material/MenuItem';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import { supabase } from '../../lib/supabase';
import type { Trainer } from '../../lib/supabase';

const EMPTY_FORM = { full_name: '', specialty: '', phone: '', email: '', bio: '', is_active: true };
const SPECIALTIES = ['Musculación & Fuerza', 'CrossFit & Funcional', 'Cardio & Resistencia', 'Yoga & Pilates', 'Artes Marciales', 'Natación', 'Nutrición Deportiva', 'Rehabilitación'];
const COLORS = ['#FF6B35', '#1DB954', '#2196F3', '#FFB800', '#9C27B0', '#F44336', '#00BCD4', '#FF5722'];

export default function TrainersPage() {
  const [trainers, setTrainers] = useState<Trainer[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editId, setEditId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    const { data } = await supabase.from('trainers').select('*').order('created_at', { ascending: false });
    setTrainers((data || []) as Trainer[]);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const openNew = () => { setForm(EMPTY_FORM); setEditId(null); setError(''); setDialogOpen(true); };
  const openEdit = (t: Trainer) => {
    setForm({ full_name: t.full_name, specialty: t.specialty, phone: t.phone, email: t.email, bio: t.bio, is_active: t.is_active });
    setEditId(t.id);
    setError('');
    setDialogOpen(true);
  };

  const handleToggle = async (t: Trainer) => {
    await supabase.from('trainers').update({ is_active: !t.is_active }).eq('id', t.id);
    fetchData();
  };

  const handleSave = async () => {
    if (!form.full_name) { setError('El nombre es requerido.'); return; }
    setSaving(true);
    setError('');
    const { error: err } = editId
      ? await supabase.from('trainers').update({ ...form, updated_at: new Date().toISOString() }).eq('id', editId)
      : await supabase.from('trainers').insert(form);
    if (err) { setError(err.message); setSaving(false); return; }
    await fetchData();
    setDialogOpen(false);
    setSaving(false);
  };

  const getColor = (i: number) => COLORS[i % COLORS.length];

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Entrenadores</Typography>
          <Typography color="text.secondary">{trainers.length} entrenadores registrados</Typography>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={openNew}>Nuevo Entrenador</Button>
      </Box>

      <Grid container spacing={3}>
        {loading ? Array.from({ length: 6 }).map((_, i) => (
          <Grid key={i} size={{ xs: 12, sm: 6, md: 4 }}>
            <Card sx={{ p: 3 }}><Skeleton height={200} /></Card>
          </Grid>
        )) : trainers.map((t, i) => {
          const color = getColor(i);
          const initials = t.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
          return (
            <Grid key={t.id} size={{ xs: 12, sm: 6, md: 4 }}>
              <Card sx={{ p: 3, opacity: t.is_active ? 1 : 0.6, transition: 'all 0.2s', '&:hover': { transform: 'translateY(-2px)', boxShadow: `0 8px 30px ${color}20` } }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
                  <Avatar sx={{ width: 56, height: 56, bgcolor: color, fontWeight: 800, fontSize: '1.2rem' }}>{initials}</Avatar>
                  <Box sx={{ display: 'flex', gap: 0.5 }}>
                    <Tooltip title="Editar">
                      <IconButton size="small" onClick={() => openEdit(t)}><EditIcon fontSize="small" /></IconButton>
                    </Tooltip>
                    <Switch checked={t.is_active} size="small" onChange={() => handleToggle(t)} color="success" />
                  </Box>
                </Box>
                <Typography variant="h6" fontWeight={700}>{t.full_name}</Typography>
                {t.specialty && (
                  <Chip label={t.specialty} size="small" sx={{ mb: 2, bgcolor: `${color}20`, color, fontWeight: 600 }} />
                )}
                {t.bio && <Typography variant="body2" color="text.secondary" sx={{ mb: 2, lineHeight: 1.6 }}>{t.bio}</Typography>}
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                  {t.phone && (
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <PhoneIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
                      <Typography variant="caption" color="text.secondary">{t.phone}</Typography>
                    </Box>
                  )}
                  {t.email && (
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <EmailIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
                      <Typography variant="caption" color="text.secondary">{t.email}</Typography>
                    </Box>
                  )}
                </Box>
              </Card>
            </Grid>
          );
        })}
        {!loading && trainers.length === 0 && (
          <Grid size={{ xs: 12 }}>
            <Card sx={{ p: 6, textAlign: 'center' }}>
              <FitnessCenterIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
              <Typography color="text.secondary">No hay entrenadores registrados</Typography>
            </Card>
          </Grid>
        )}
      </Grid>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editId ? 'Editar Entrenador' : 'Nuevo Entrenador'}</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Nombre completo *" value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField select fullWidth label="Especialidad" value={form.specialty} onChange={e => setForm(p => ({ ...p, specialty: e.target.value }))}>
                <MenuItem value="">Sin especialidad</MenuItem>
                {SPECIALTIES.map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField fullWidth label="Teléfono" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField fullWidth label="Correo" type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Biografía" multiline rows={3} value={form.bio} onChange={e => setForm(p => ({ ...p, bio: e.target.value }))} />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setDialogOpen(false)} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.primary' }}>Cancelar</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Guardar'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
