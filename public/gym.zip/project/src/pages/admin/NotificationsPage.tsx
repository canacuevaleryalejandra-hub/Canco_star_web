import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Chip from '@mui/material/Chip';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import Divider from '@mui/material/Divider';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import AddIcon from '@mui/icons-material/Add';
import NotificationsIcon from '@mui/icons-material/Notifications';
import InfoIcon from '@mui/icons-material/Info';
import WarningIcon from '@mui/icons-material/Warning';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import { supabase } from '../../lib/supabase';
import { timeAgo } from '../../utils/helpers';
import type { Notification, Profile } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';

const TYPE_ICONS: Record<string, React.ReactNode> = {
  info: <InfoIcon sx={{ color: '#2196F3' }} />,
  warning: <WarningIcon sx={{ color: '#FFB800' }} />,
  success: <CheckCircleIcon sx={{ color: '#1DB954' }} />,
  error: <ErrorIcon sx={{ color: '#FF4444' }} />,
};

const TYPE_COLORS: Record<string, string> = {
  info: '#2196F3', warning: '#FFB800', success: '#1DB954', error: '#FF4444',
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ title: '', message: '', type: 'info' as Notification['type'], user_ids: [] as string[] });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const { user } = useAuth();

  const fetchData = async () => {
    const [notifRes, usersRes] = await Promise.all([
      supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50),
      supabase.from('profiles').select('id, full_name, role'),
    ]);
    setNotifications((notifRes.data || []) as Notification[]);
    setUsers((usersRes.data || []) as Profile[]);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const handleMarkRead = async (id: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    fetchData();
  };

  const handleMarkAllRead = async () => {
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', user?.id || '');
    fetchData();
  };

  const handleSend = async () => {
    if (!form.title || !form.message) { setError('Título y mensaje son requeridos.'); return; }
    if (form.user_ids.length === 0) { setError('Selecciona al menos un destinatario.'); return; }
    setSaving(true);
    setError('');
    const inserts = form.user_ids.map(uid => ({ title: form.title, message: form.message, type: form.type, user_id: uid }));
    const { error: err } = await supabase.from('notifications').insert(inserts);
    if (err) { setError(err.message); setSaving(false); return; }
    await fetchData();
    setDialogOpen(false);
    setForm({ title: '', message: '', type: 'info', user_ids: [] });
    setSaving(false);
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Notificaciones</Typography>
          <Typography color="text.secondary">{unreadCount} sin leer</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          {unreadCount > 0 && (
            <Button variant="outlined" onClick={handleMarkAllRead} sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.secondary' }}>
              Marcar todas como leídas
            </Button>
          )}
          <Button variant="contained" startIcon={<AddIcon />} onClick={() => { setError(''); setDialogOpen(true); }}>
            Nueva Notificación
          </Button>
        </Box>
      </Box>

      <Card>
        {loading ? (
          <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>
        ) : notifications.length === 0 ? (
          <Box sx={{ p: 6, textAlign: 'center' }}>
            <NotificationsIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
            <Typography color="text.secondary">No hay notificaciones</Typography>
          </Box>
        ) : (
          <List disablePadding>
            {notifications.map((n, i) => (
              <Box key={n.id}>
                {i > 0 && <Divider />}
                <ListItem
                  sx={{
                    py: 2, px: 3,
                    bgcolor: n.is_read ? 'transparent' : `${TYPE_COLORS[n.type]}08`,
                    borderLeft: n.is_read ? '3px solid transparent' : `3px solid ${TYPE_COLORS[n.type]}`,
                  }}
                  secondaryAction={
                    !n.is_read && (
                      <Button size="small" onClick={() => handleMarkRead(n.id)} sx={{ color: 'text.secondary', fontSize: '0.75rem' }}>
                        Marcar leída
                      </Button>
                    )
                  }
                >
                  <ListItemIcon sx={{ minWidth: 40 }}>
                    {TYPE_ICONS[n.type]}
                  </ListItemIcon>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="body2" fontWeight={n.is_read ? 400 : 700}>{n.title}</Typography>
                        {!n.is_read && <Chip label="Nuevo" size="small" sx={{ bgcolor: `${TYPE_COLORS[n.type]}20`, color: TYPE_COLORS[n.type], height: 18, fontSize: '0.65rem' }} />}
                      </Box>
                    }
                    secondary={
                      <Box>
                        <Typography variant="caption" color="text.secondary">{n.message}</Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>{timeAgo(n.created_at)}</Typography>
                      </Box>
                    }
                  />
                </ListItem>
              </Box>
            ))}
          </List>
        )}
      </Card>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Enviar Notificación</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Título *" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Mensaje *" multiline rows={3} value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField select fullWidth label="Tipo" value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value as Notification['type'] }))}>
                <MenuItem value="info">ℹ️ Información</MenuItem>
                <MenuItem value="warning">⚠️ Advertencia</MenuItem>
                <MenuItem value="success">✅ Éxito</MenuItem>
                <MenuItem value="error">❌ Error</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <FormControl fullWidth size="small">
                <InputLabel>Destinatarios *</InputLabel>
                <Select
                  multiple
                  value={form.user_ids}
                  onChange={e => setForm(p => ({ ...p, user_ids: typeof e.target.value === 'string' ? [e.target.value] : e.target.value }))}
                  label="Destinatarios *"
                  renderValue={selected => (
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {(selected as string[]).map(id => {
                        const u = users.find(u => u.id === id);
                        return <Chip key={id} label={u?.full_name || id} size="small" />;
                      })}
                    </Box>
                  )}
                >
                  {users.map(u => (
                    <MenuItem key={u.id} value={u.id}>
                      {u.full_name} <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>({u.role})</Typography>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setDialogOpen(false)} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.primary' }}>Cancelar</Button>
          <Button variant="contained" onClick={handleSend} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Enviar'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
