import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Avatar from '@mui/material/Avatar';
import Chip from '@mui/material/Chip';
import IconButton from '@mui/material/IconButton';
import Skeleton from '@mui/material/Skeleton';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import InputAdornment from '@mui/material/InputAdornment';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import Tooltip from '@mui/material/Tooltip';
import TablePagination from '@mui/material/TablePagination';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import PersonIcon from '@mui/icons-material/Person';
import { supabase } from '../../lib/supabase';
import { formatDate, getStatusColor, getStatusLabel } from '../../utils/helpers';
import type { Client, Membership, Trainer } from '../../lib/supabase';

const EMPTY_FORM = {
  first_name: '', last_name: '', document_number: '', phone: '', email: '',
  address: '', birth_date: '', gender: '' as '' | 'male' | 'female' | 'other',
  membership_id: '', trainer_id: '', start_date: '', end_date: '',
  status: 'active' as 'active' | 'inactive' | 'expired' | 'pending', notes: '',
};

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [trainers, setTrainers] = useState<Trainer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(0);
  const [rowsPerPage] = useState(10);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editId, setEditId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    const [clientsRes, membershipsRes, trainersRes] = await Promise.all([
      supabase.from('clients').select('*, memberships(id, name, price), trainers(id, full_name)').order('created_at', { ascending: false }),
      supabase.from('memberships').select('*').eq('is_active', true),
      supabase.from('trainers').select('*').eq('is_active', true),
    ]);
    setClients((clientsRes.data || []) as Client[]);
    setMemberships((membershipsRes.data || []) as Membership[]);
    setTrainers((trainersRes.data || []) as Trainer[]);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const filtered = clients.filter(c => {
    const q = search.toLowerCase();
    const matchSearch = !q || `${c.first_name} ${c.last_name} ${c.email} ${c.document_number}`.toLowerCase().includes(q);
    const matchStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const paginated = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  const openNew = () => { setForm(EMPTY_FORM); setEditId(null); setError(''); setDialogOpen(true); };
  const openEdit = (c: Client) => {
    setForm({
      first_name: c.first_name, last_name: c.last_name, document_number: c.document_number,
      phone: c.phone, email: c.email, address: c.address,
      birth_date: c.birth_date || '', gender: c.gender || '',
      membership_id: c.membership_id || '', trainer_id: c.trainer_id || '',
      start_date: c.start_date || '', end_date: c.end_date || '',
      status: c.status, notes: c.notes,
    });
    setEditId(c.id);
    setError('');
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.first_name || !form.last_name || !form.email) { setError('Nombre, apellido y correo son requeridos.'); return; }
    setSaving(true);
    setError('');
    const payload = {
      ...form,
      membership_id: form.membership_id || null,
      trainer_id: form.trainer_id || null,
      birth_date: form.birth_date || null,
      start_date: form.start_date || null,
      end_date: form.end_date || null,
    };
    const { error: err } = editId
      ? await supabase.from('clients').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editId)
      : await supabase.from('clients').insert(payload);
    if (err) { setError(err.message); setSaving(false); return; }
    await fetchData();
    setDialogOpen(false);
    setSaving(false);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Clientes</Typography>
          <Typography color="text.secondary">{clients.length} clientes registrados</Typography>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={openNew}>Nuevo Cliente</Button>
      </Box>

      {/* Filters */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 5 }}>
          <TextField
            fullWidth placeholder="Buscar por nombre, correo o documento..."
            value={search} onChange={e => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment> }}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 3 }}>
          <TextField select fullWidth value={statusFilter} onChange={e => setStatusFilter(e.target.value)} label="Estado">
            <MenuItem value="all">Todos</MenuItem>
            <MenuItem value="active">Activo</MenuItem>
            <MenuItem value="inactive">Inactivo</MenuItem>
            <MenuItem value="expired">Vencido</MenuItem>
            <MenuItem value="pending">Pendiente</MenuItem>
          </TextField>
        </Grid>
      </Grid>

      <Card>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Cliente</TableCell>
                <TableCell>Documento</TableCell>
                <TableCell>Teléfono</TableCell>
                <TableCell>Membresía</TableCell>
                <TableCell>Vencimiento</TableCell>
                <TableCell>Estado</TableCell>
                <TableCell align="center">Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? Array.from({ length: 6 }).map((_, i) => (
                <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton /></TableCell>)}</TableRow>
              )) : paginated.map(c => (
                <TableRow key={c.id} hover>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      <Avatar sx={{ width: 36, height: 36, bgcolor: 'primary.main', fontWeight: 700, fontSize: '0.85rem' }}>
                        {c.first_name[0]}{c.last_name[0]}
                      </Avatar>
                      <Box>
                        <Typography variant="body2" fontWeight={600}>{c.first_name} {c.last_name}</Typography>
                        <Typography variant="caption" color="text.secondary">{c.email}</Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell><Typography variant="body2">{c.document_number || '-'}</Typography></TableCell>
                  <TableCell><Typography variant="body2">{c.phone || '-'}</Typography></TableCell>
                  <TableCell><Typography variant="body2">{c.memberships?.name || '-'}</Typography></TableCell>
                  <TableCell><Typography variant="body2">{formatDate(c.end_date)}</Typography></TableCell>
                  <TableCell><Chip label={getStatusLabel(c.status)} color={getStatusColor(c.status)} size="small" /></TableCell>
                  <TableCell align="center">
                    <Tooltip title="Editar">
                      <IconButton size="small" onClick={() => openEdit(c)}><EditIcon fontSize="small" /></IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
              {!loading && paginated.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} align="center" sx={{ py: 6 }}>
                    <PersonIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 1 }} />
                    <Typography color="text.secondary">No se encontraron clientes</Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          component="div"
          count={filtered.length}
          page={page}
          onPageChange={(_, p) => setPage(p)}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={() => {}}
          labelRowsPerPage="Por página:"
          labelDisplayedRows={({ from, to, count }) => `${from}–${to} de ${count}`}
        />
      </Card>

      {/* Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>{editId ? 'Editar Cliente' : 'Nuevo Cliente'}</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            {[
              { label: 'Nombre *', field: 'first_name' }, { label: 'Apellido *', field: 'last_name' },
              { label: 'Documento', field: 'document_number' }, { label: 'Teléfono', field: 'phone' },
              { label: 'Correo *', field: 'email', type: 'email' }, { label: 'Dirección', field: 'address' },
              { label: 'Fecha de Nacimiento', field: 'birth_date', type: 'date' },
            ].map(f => (
              <Grid key={f.field} size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth label={f.label} type={f.type || 'text'}
                  value={form[f.field as keyof typeof form]}
                  onChange={e => setForm(prev => ({ ...prev, [f.field]: e.target.value }))}
                  InputLabelProps={f.type === 'date' ? { shrink: true } : undefined}
                />
              </Grid>
            ))}
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField select fullWidth label="Género" value={form.gender} onChange={e => setForm(prev => ({ ...prev, gender: e.target.value as typeof form.gender }))}>
                <MenuItem value="">Sin especificar</MenuItem>
                <MenuItem value="male">Masculino</MenuItem>
                <MenuItem value="female">Femenino</MenuItem>
                <MenuItem value="other">Otro</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField select fullWidth label="Membresía" value={form.membership_id} onChange={e => setForm(prev => ({ ...prev, membership_id: e.target.value }))}>
                <MenuItem value="">Sin membresía</MenuItem>
                {memberships.map(m => <MenuItem key={m.id} value={m.id}>{m.name} — $ {Number(m.price).toLocaleString('es-CO')}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField select fullWidth label="Entrenador" value={form.trainer_id} onChange={e => setForm(prev => ({ ...prev, trainer_id: e.target.value }))}>
                <MenuItem value="">Sin asignar</MenuItem>
                {trainers.map(t => <MenuItem key={t.id} value={t.id}>{t.full_name}</MenuItem>)}
              </TextField>
            </Grid>
            {[
              { label: 'Fecha de Inicio', field: 'start_date' }, { label: 'Fecha de Vencimiento', field: 'end_date' },
            ].map(f => (
              <Grid key={f.field} size={{ xs: 12, sm: 6 }}>
                <TextField fullWidth label={f.label} type="date" value={form[f.field as keyof typeof form]}
                  onChange={e => setForm(prev => ({ ...prev, [f.field]: e.target.value }))}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
            ))}
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField select fullWidth label="Estado" value={form.status} onChange={e => setForm(prev => ({ ...prev, status: e.target.value as typeof form.status }))}>
                <MenuItem value="active">Activo</MenuItem>
                <MenuItem value="inactive">Inactivo</MenuItem>
                <MenuItem value="expired">Vencido</MenuItem>
                <MenuItem value="pending">Pendiente</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Notas" multiline rows={2} value={form.notes}
                onChange={e => setForm(prev => ({ ...prev, notes: e.target.value }))}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setDialogOpen(false)} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.primary' }}>Cancelar</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Guardar'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
