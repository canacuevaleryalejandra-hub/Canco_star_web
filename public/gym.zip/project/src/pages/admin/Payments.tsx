import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Avatar from '@mui/material/Avatar';
import Chip from '@mui/material/Chip';
import Skeleton from '@mui/material/Skeleton';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import InputAdornment from '@mui/material/InputAdornment';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import { supabase } from '../../lib/supabase';
import { formatDate, formatCurrency, getStatusColor, getStatusLabel, getPaymentMethodLabel } from '../../utils/helpers';
import type { Payment, Client, Membership } from '../../lib/supabase';

const EMPTY_FORM = {
  client_id: '', membership_id: '', amount: 0,
  payment_method: 'cash' as Payment['payment_method'],
  payment_date: new Date().toISOString().split('T')[0],
  reference: '', status: 'completed' as Payment['status'], notes: '',
};

const METHOD_ICONS: Record<string, string> = {
  cash: '💵', card: '💳', transfer: '🏦', nequi: '📱', daviplata: '📱',
};

export default function PaymentsPage() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [methodFilter, setMethodFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    const [paymentsRes, clientsRes, membershipsRes] = await Promise.all([
      supabase.from('payments').select('*, clients(id, first_name, last_name, email), memberships(id, name)').order('created_at', { ascending: false }),
      supabase.from('clients').select('id, first_name, last_name').eq('status', 'active'),
      supabase.from('memberships').select('id, name, price').eq('is_active', true),
    ]);
    setPayments((paymentsRes.data || []) as Payment[]);
    setClients((clientsRes.data || []) as Client[]);
    setMemberships((membershipsRes.data || []) as Membership[]);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const filtered = payments.filter(p => {
    const q = search.toLowerCase();
    const name = `${p.clients?.first_name || ''} ${p.clients?.last_name || ''}`.toLowerCase();
    const matchSearch = !q || name.includes(q) || (p.reference || '').toLowerCase().includes(q);
    const matchMethod = methodFilter === 'all' || p.payment_method === methodFilter;
    return matchSearch && matchMethod;
  });

  const totalRevenue = filtered.reduce((sum, p) => p.status === 'completed' ? sum + Number(p.amount) : sum, 0);
  const todayRevenue = filtered.filter(p => p.payment_date === new Date().toISOString().split('T')[0] && p.status === 'completed').reduce((s, p) => s + Number(p.amount), 0);

  const handleSave = async () => {
    if (!form.client_id || !form.amount) { setError('Cliente y monto son requeridos.'); return; }
    setSaving(true);
    setError('');
    const { error: err } = await supabase.from('payments').insert({ ...form, amount: Number(form.amount), membership_id: form.membership_id || null });
    if (err) { setError(err.message); setSaving(false); return; }
    await fetchData();
    setDialogOpen(false);
    setSaving(false);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Pagos</Typography>
          <Typography color="text.secondary">{payments.length} transacciones</Typography>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => { setForm(EMPTY_FORM); setError(''); setDialogOpen(true); }}>Registrar Pago</Button>
      </Box>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {[
          { title: 'Ingresos Totales', value: formatCurrency(totalRevenue, '$'), icon: <AttachMoneyIcon />, color: '#1DB954' },
          { title: 'Ingresos Hoy', value: formatCurrency(todayRevenue, '$'), icon: <TrendingUpIcon />, color: '#FF6B35' },
          { title: 'Total Transacciones', value: payments.length, icon: <AttachMoneyIcon />, color: '#2196F3' },
        ].map(s => (
          <Grid key={s.title} size={{ xs: 12, sm: 4 }}>
            <Card sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, textTransform: 'uppercase', fontSize: '0.7rem', letterSpacing: '0.06em' }}>{s.title}</Typography>
                  <Typography variant="h5" fontWeight={800} sx={{ mt: 0.5 }}>{s.value}</Typography>
                </Box>
                <Box sx={{ p: 1.5, bgcolor: `${s.color}20`, borderRadius: 2, color: s.color }}>{s.icon}</Box>
              </Box>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 5 }}>
          <TextField fullWidth placeholder="Buscar por cliente o referencia..." value={search} onChange={e => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ color: 'text.secondary', fontSize: 18 }} /></InputAdornment> }} />
        </Grid>
        <Grid size={{ xs: 12, sm: 3 }}>
          <TextField select fullWidth value={methodFilter} onChange={e => setMethodFilter(e.target.value)} label="Método">
            <MenuItem value="all">Todos</MenuItem>
            {['cash', 'card', 'transfer', 'nequi', 'daviplata'].map(m => (
              <MenuItem key={m} value={m}>{METHOD_ICONS[m]} {getPaymentMethodLabel(m)}</MenuItem>
            ))}
          </TextField>
        </Grid>
      </Grid>

      <Card>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Cliente</TableCell>
                <TableCell>Membresía</TableCell>
                <TableCell>Método</TableCell>
                <TableCell align="right">Monto</TableCell>
                <TableCell>Fecha</TableCell>
                <TableCell>Referencia</TableCell>
                <TableCell>Estado</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? Array.from({ length: 6 }).map((_, i) => (
                <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton /></TableCell>)}</TableRow>
              )) : filtered.slice(0, 50).map(p => (
                <TableRow key={p.id} hover>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                      <Avatar sx={{ width: 32, height: 32, bgcolor: 'secondary.main', fontWeight: 700, fontSize: '0.8rem' }}>
                        {p.clients?.first_name?.[0] || '?'}
                      </Avatar>
                      <Typography variant="body2" fontWeight={600}>{p.clients?.first_name} {p.clients?.last_name}</Typography>
                    </Box>
                  </TableCell>
                  <TableCell><Typography variant="body2">{p.memberships?.name || '-'}</Typography></TableCell>
                  <TableCell>
                    <Chip label={`${METHOD_ICONS[p.payment_method]} ${getPaymentMethodLabel(p.payment_method)}`} size="small" sx={{ bgcolor: 'rgba(255,255,255,0.06)' }} />
                  </TableCell>
                  <TableCell align="right"><Typography variant="body2" fontWeight={700} color="secondary.main">$ {Number(p.amount).toLocaleString('es-CO')}</Typography></TableCell>
                  <TableCell><Typography variant="body2">{formatDate(p.payment_date)}</Typography></TableCell>
                  <TableCell><Typography variant="caption" color="text.secondary">{p.reference || '-'}</Typography></TableCell>
                  <TableCell><Chip label={getStatusLabel(p.status)} color={getStatusColor(p.status)} size="small" /></TableCell>
                </TableRow>
              ))}
              {!loading && filtered.length === 0 && (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6 }}><Typography color="text.secondary">No se encontraron pagos</Typography></TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Registrar Pago</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12 }}>
              <TextField select fullWidth label="Cliente *" value={form.client_id} onChange={e => setForm(prev => ({ ...prev, client_id: e.target.value }))}>
                {clients.map(c => <MenuItem key={c.id} value={c.id}>{c.first_name} {c.last_name}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField select fullWidth label="Membresía" value={form.membership_id} onChange={e => {
                const m = memberships.find(m => m.id === e.target.value);
                setForm(prev => ({ ...prev, membership_id: e.target.value, amount: m ? m.price : prev.amount }));
              }}>
                <MenuItem value="">Sin membresía</MenuItem>
                {memberships.map(m => <MenuItem key={m.id} value={m.id}>{m.name} — $ {Number(m.price).toLocaleString('es-CO')}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField fullWidth label="Monto *" type="number" value={form.amount} onChange={e => setForm(prev => ({ ...prev, amount: Number(e.target.value) }))} InputProps={{ startAdornment: <Box component="span" sx={{ mr: 1, color: 'text.secondary' }}>$</Box> }} />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField select fullWidth label="Método de Pago" value={form.payment_method} onChange={e => setForm(prev => ({ ...prev, payment_method: e.target.value as Payment['payment_method'] }))}>
                {['cash', 'card', 'transfer', 'nequi', 'daviplata'].map(m => <MenuItem key={m} value={m}>{METHOD_ICONS[m]} {getPaymentMethodLabel(m)}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField fullWidth label="Fecha" type="date" value={form.payment_date} onChange={e => setForm(prev => ({ ...prev, payment_date: e.target.value }))} InputLabelProps={{ shrink: true }} />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField select fullWidth label="Estado" value={form.status} onChange={e => setForm(prev => ({ ...prev, status: e.target.value as Payment['status'] }))}>
                <MenuItem value="completed">Completado</MenuItem>
                <MenuItem value="pending">Pendiente</MenuItem>
                <MenuItem value="cancelled">Cancelado</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Referencia" value={form.reference} onChange={e => setForm(prev => ({ ...prev, reference: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Notas" multiline rows={2} value={form.notes} onChange={e => setForm(prev => ({ ...prev, notes: e.target.value }))} />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setDialogOpen(false)} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.primary' }}>Cancelar</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Registrar'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
