import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Chip from '@mui/material/Chip';
import IconButton from '@mui/material/IconButton';
import Skeleton from '@mui/material/Skeleton';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import CircularProgress from '@mui/material/CircularProgress';
import Alert from '@mui/material/Alert';
import Tooltip from '@mui/material/Tooltip';
import Divider from '@mui/material/Divider';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import AssignmentIcon from '@mui/icons-material/Assignment';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import { supabase } from '../../lib/supabase';
import { getDifficultyLabel } from '../../utils/helpers';
import type { Routine, Client, Trainer, Exercise } from '../../lib/supabase';

const EMPTY_ROUTINE = { client_id: '', trainer_id: '', title: '', description: '', days_per_week: 3, duration_weeks: 4, difficulty: 'intermediate' as Routine['difficulty'], goal: '', is_active: true };
const EMPTY_EXERCISE = { name: '', muscle_group: '', sets: 3, reps: '10', rest_seconds: 60, day_number: 1, notes: '', order_index: 0 };

const MUSCLE_GROUPS = ['Pecho', 'Espalda', 'Hombros', 'Bíceps', 'Tríceps', 'Piernas', 'Glúteos', 'Core', 'Cardio', 'Full Body'];
const DIFF_COLORS: Record<string, string> = { beginner: '#1DB954', intermediate: '#FFB800', advanced: '#FF6B35' };

export default function RoutinesPage() {
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [trainers, setTrainers] = useState<Trainer[]>([]);
  const [loading, setLoading] = useState(true);
  const [routineDialog, setRoutineDialog] = useState(false);
  const [exerciseDialog, setExerciseDialog] = useState(false);
  const [routineForm, setRoutineForm] = useState(EMPTY_ROUTINE);
  const [exerciseForm, setExerciseForm] = useState(EMPTY_EXERCISE);
  const [editRoutineId, setEditRoutineId] = useState<string | null>(null);
  const [activeRoutineId, setActiveRoutineId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    const [routinesRes, clientsRes, trainersRes] = await Promise.all([
      supabase.from('routines').select('*, clients(id, first_name, last_name), trainers(id, full_name), exercises(*)').order('created_at', { ascending: false }),
      supabase.from('clients').select('id, first_name, last_name'),
      supabase.from('trainers').select('id, full_name').eq('is_active', true),
    ]);
    setRoutines((routinesRes.data || []) as Routine[]);
    setClients((clientsRes.data || []) as Client[]);
    setTrainers((trainersRes.data || []) as Trainer[]);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const openNewRoutine = () => { setRoutineForm(EMPTY_ROUTINE); setEditRoutineId(null); setError(''); setRoutineDialog(true); };
  const openEditRoutine = (r: Routine) => {
    setRoutineForm({ client_id: r.client_id, trainer_id: r.trainer_id || '', title: r.title, description: r.description, days_per_week: r.days_per_week, duration_weeks: r.duration_weeks, difficulty: r.difficulty, goal: r.goal, is_active: r.is_active });
    setEditRoutineId(r.id);
    setError('');
    setRoutineDialog(true);
  };

  const handleSaveRoutine = async () => {
    if (!routineForm.client_id || !routineForm.title) { setError('Cliente y título son requeridos.'); return; }
    setSaving(true);
    setError('');
    const payload = { ...routineForm, trainer_id: routineForm.trainer_id || null };
    const { error: err } = editRoutineId
      ? await supabase.from('routines').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editRoutineId)
      : await supabase.from('routines').insert(payload);
    if (err) { setError(err.message); setSaving(false); return; }
    await fetchData();
    setRoutineDialog(false);
    setSaving(false);
  };

  const openAddExercise = (routineId: string) => {
    setActiveRoutineId(routineId);
    setExerciseForm(EMPTY_EXERCISE);
    setError('');
    setExerciseDialog(true);
  };

  const handleSaveExercise = async () => {
    if (!exerciseForm.name) { setError('El nombre del ejercicio es requerido.'); return; }
    setSaving(true);
    setError('');
    const { error: err } = await supabase.from('exercises').insert({ ...exerciseForm, routine_id: activeRoutineId, sets: Number(exerciseForm.sets), rest_seconds: Number(exerciseForm.rest_seconds), day_number: Number(exerciseForm.day_number) });
    if (err) { setError(err.message); setSaving(false); return; }
    await fetchData();
    setExerciseDialog(false);
    setSaving(false);
  };

  const deleteExercise = async (id: string) => {
    await supabase.from('exercises').delete().eq('id', id);
    fetchData();
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={800}>Rutinas</Typography>
          <Typography color="text.secondary">{routines.length} rutinas registradas</Typography>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={openNewRoutine}>Nueva Rutina</Button>
      </Box>

      {loading ? (
        <Grid container spacing={3}>
          {Array.from({ length: 4 }).map((_, i) => <Grid key={i} size={{ xs: 12, md: 6 }}><Card sx={{ p: 3 }}><Skeleton height={150} /></Card></Grid>)}
        </Grid>
      ) : routines.length === 0 ? (
        <Card sx={{ p: 6, textAlign: 'center' }}>
          <AssignmentIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
          <Typography color="text.secondary">No hay rutinas registradas</Typography>
        </Card>
      ) : (
        routines.map(r => (
          <Accordion key={r.id} sx={{ mb: 2, background: '#141414', border: '1px solid rgba(255,255,255,0.06)', '&:before': { display: 'none' } }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flex: 1, pr: 2 }}>
                <Box sx={{ p: 1, bgcolor: `${DIFF_COLORS[r.difficulty]}20`, borderRadius: 1.5 }}>
                  <FitnessCenterIcon sx={{ fontSize: 18, color: DIFF_COLORS[r.difficulty] }} />
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography fontWeight={700}>{r.title}</Typography>
                  <Typography variant="caption" color="text.secondary">
                    {r.clients?.first_name} {r.clients?.last_name} • {r.days_per_week} días/sem • {r.duration_weeks} semanas
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Chip label={getDifficultyLabel(r.difficulty)} size="small" sx={{ bgcolor: `${DIFF_COLORS[r.difficulty]}20`, color: DIFF_COLORS[r.difficulty] }} />
                  <Chip label={`${r.exercises?.length || 0} ejercicios`} size="small" sx={{ bgcolor: 'rgba(255,255,255,0.06)' }} />
                  <Tooltip title="Editar"><IconButton size="small" onClick={e => { e.stopPropagation(); openEditRoutine(r); }}><EditIcon fontSize="small" /></IconButton></Tooltip>
                </Box>
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <Divider sx={{ mb: 2 }} />
              {r.description && <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{r.description}</Typography>}
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                <Typography variant="subtitle2" fontWeight={700}>Ejercicios</Typography>
                <Button size="small" startIcon={<AddIcon />} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.secondary' }} onClick={() => openAddExercise(r.id)}>
                  Agregar Ejercicio
                </Button>
              </Box>
              {r.exercises && r.exercises.length > 0 ? (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Ejercicio</TableCell>
                        <TableCell>Músculo</TableCell>
                        <TableCell align="center">Series</TableCell>
                        <TableCell align="center">Reps</TableCell>
                        <TableCell align="center">Descanso</TableCell>
                        <TableCell align="center">Día</TableCell>
                        <TableCell />
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {(r.exercises as Exercise[]).map(ex => (
                        <TableRow key={ex.id}>
                          <TableCell><Typography variant="body2" fontWeight={600}>{ex.name}</Typography></TableCell>
                          <TableCell><Chip label={ex.muscle_group || '-'} size="small" sx={{ bgcolor: 'rgba(255,255,255,0.06)' }} /></TableCell>
                          <TableCell align="center"><Typography variant="body2">{ex.sets}</Typography></TableCell>
                          <TableCell align="center"><Typography variant="body2">{ex.reps}</Typography></TableCell>
                          <TableCell align="center"><Typography variant="body2">{ex.rest_seconds}s</Typography></TableCell>
                          <TableCell align="center"><Chip label={`Día ${ex.day_number}`} size="small" sx={{ bgcolor: 'rgba(29,185,84,0.1)', color: 'secondary.main' }} /></TableCell>
                          <TableCell><IconButton size="small" color="error" onClick={() => deleteExercise(ex.id)}>✕</IconButton></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              ) : (
                <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>No hay ejercicios en esta rutina</Typography>
              )}
            </AccordionDetails>
          </Accordion>
        ))
      )}

      {/* Routine Dialog */}
      <Dialog open={routineDialog} onClose={() => setRoutineDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editRoutineId ? 'Editar Rutina' : 'Nueva Rutina'}</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12 }}>
              <TextField select fullWidth label="Cliente *" value={routineForm.client_id} onChange={e => setRoutineForm(p => ({ ...p, client_id: e.target.value }))}>
                {clients.map(c => <MenuItem key={c.id} value={c.id}>{c.first_name} {c.last_name}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField select fullWidth label="Entrenador" value={routineForm.trainer_id} onChange={e => setRoutineForm(p => ({ ...p, trainer_id: e.target.value }))}>
                <MenuItem value="">Sin asignar</MenuItem>
                {trainers.map(t => <MenuItem key={t.id} value={t.id}>{t.full_name}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Título *" value={routineForm.title} onChange={e => setRoutineForm(p => ({ ...p, title: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Descripción" multiline rows={2} value={routineForm.description} onChange={e => setRoutineForm(p => ({ ...p, description: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 4 }}>
              <TextField fullWidth label="Días/semana" type="number" inputProps={{ min: 1, max: 7 }} value={routineForm.days_per_week} onChange={e => setRoutineForm(p => ({ ...p, days_per_week: Number(e.target.value) }))} />
            </Grid>
            <Grid size={{ xs: 4 }}>
              <TextField fullWidth label="Semanas" type="number" value={routineForm.duration_weeks} onChange={e => setRoutineForm(p => ({ ...p, duration_weeks: Number(e.target.value) }))} />
            </Grid>
            <Grid size={{ xs: 4 }}>
              <TextField select fullWidth label="Dificultad" value={routineForm.difficulty} onChange={e => setRoutineForm(p => ({ ...p, difficulty: e.target.value as Routine['difficulty'] }))}>
                <MenuItem value="beginner">Principiante</MenuItem>
                <MenuItem value="intermediate">Intermedio</MenuItem>
                <MenuItem value="advanced">Avanzado</MenuItem>
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Objetivo" value={routineForm.goal} onChange={e => setRoutineForm(p => ({ ...p, goal: e.target.value }))} />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setRoutineDialog(false)} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.primary' }}>Cancelar</Button>
          <Button variant="contained" onClick={handleSaveRoutine} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Guardar'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Exercise Dialog */}
      <Dialog open={exerciseDialog} onClose={() => setExerciseDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Agregar Ejercicio</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Nombre del ejercicio *" value={exerciseForm.name} onChange={e => setExerciseForm(p => ({ ...p, name: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField select fullWidth label="Grupo muscular" value={exerciseForm.muscle_group} onChange={e => setExerciseForm(p => ({ ...p, muscle_group: e.target.value }))}>
                <MenuItem value="">Sin especificar</MenuItem>
                {MUSCLE_GROUPS.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid size={{ xs: 4 }}>
              <TextField fullWidth label="Series" type="number" value={exerciseForm.sets} onChange={e => setExerciseForm(p => ({ ...p, sets: Number(e.target.value) }))} />
            </Grid>
            <Grid size={{ xs: 4 }}>
              <TextField fullWidth label="Repeticiones" value={exerciseForm.reps} onChange={e => setExerciseForm(p => ({ ...p, reps: e.target.value }))} />
            </Grid>
            <Grid size={{ xs: 4 }}>
              <TextField fullWidth label="Descanso (s)" type="number" value={exerciseForm.rest_seconds} onChange={e => setExerciseForm(p => ({ ...p, rest_seconds: Number(e.target.value) }))} />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <TextField fullWidth label="Día N°" type="number" inputProps={{ min: 1 }} value={exerciseForm.day_number} onChange={e => setExerciseForm(p => ({ ...p, day_number: Number(e.target.value) }))} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField fullWidth label="Notas" value={exerciseForm.notes} onChange={e => setExerciseForm(p => ({ ...p, notes: e.target.value }))} />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setExerciseDialog(false)} variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: 'text.primary' }}>Cancelar</Button>
          <Button variant="contained" onClick={handleSaveExercise} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Agregar'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
