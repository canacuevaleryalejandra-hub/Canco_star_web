import { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Avatar from '@mui/material/Avatar';
import Badge from '@mui/material/Badge';
import Tooltip from '@mui/material/Tooltip';
import Divider from '@mui/material/Divider';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import CardMembershipIcon from '@mui/icons-material/CardMembership';
import PaymentIcon from '@mui/icons-material/Payment';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import AssignmentIcon from '@mui/icons-material/Assignment';
import EventNoteIcon from '@mui/icons-material/EventNote';
import NotificationsIcon from '@mui/icons-material/Notifications';
import SettingsIcon from '@mui/icons-material/Settings';
import MenuIcon from '@mui/icons-material/Menu';
import LocalFireDepartmentIcon from '@mui/icons-material/LocalFireDepartment';
import LogoutIcon from '@mui/icons-material/Logout';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { useAuth } from '../context/AuthContext';

const DRAWER_WIDTH = 240;
const COLLAPSED_WIDTH = 64;

const navItems = [
  { path: '/admin', label: 'Dashboard', icon: <DashboardIcon />, exact: true },
  { path: '/admin/clients', label: 'Clientes', icon: <PeopleIcon /> },
  { path: '/admin/memberships', label: 'Membresías', icon: <CardMembershipIcon /> },
  { path: '/admin/payments', label: 'Pagos', icon: <PaymentIcon /> },
  { path: '/admin/trainers', label: 'Entrenadores', icon: <FitnessCenterIcon /> },
  { path: '/admin/routines', label: 'Rutinas', icon: <AssignmentIcon /> },
  { path: '/admin/attendance', label: 'Asistencia', icon: <EventNoteIcon /> },
  { path: '/admin/notifications', label: 'Notificaciones', icon: <NotificationsIcon /> },
  { path: '/admin/settings', label: 'Configuración', icon: <SettingsIcon /> },
];

export default function AdminLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const drawerWidth = isMobile ? DRAWER_WIDTH : (collapsed ? COLLAPSED_WIDTH : DRAWER_WIDTH);

  const isActive = (path: string, exact?: boolean) =>
    exact ? location.pathname === path : location.pathname.startsWith(path);

  const handleNav = (path: string) => {
    navigate(path);
    if (isMobile) setMobileOpen(false);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const DrawerContent = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ p: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: 64 }}>
        {!collapsed || isMobile ? (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <LocalFireDepartmentIcon sx={{ color: 'primary.main', fontSize: 28 }} />
            <Typography variant="h6" fontWeight={800} sx={{ color: 'white' }}>
              FitPro<span style={{ color: '#FF6B35' }}>Gym</span>
            </Typography>
          </Box>
        ) : (
          <LocalFireDepartmentIcon sx={{ color: 'primary.main', fontSize: 28 }} />
        )}
        {!isMobile && (
          <IconButton size="small" onClick={() => setCollapsed(!collapsed)} sx={{ color: 'text.secondary' }}>
            <ChevronLeftIcon sx={{ transform: collapsed ? 'rotate(180deg)' : 'none', transition: 'transform 0.3s' }} />
          </IconButton>
        )}
      </Box>
      <Divider />
      <List sx={{ flex: 1, px: 1, py: 1 }}>
        {navItems.map(item => (
          <Tooltip key={item.path} title={collapsed && !isMobile ? item.label : ''} placement="right">
            <ListItemButton
              onClick={() => handleNav(item.path)}
              selected={isActive(item.path, item.exact)}
              sx={{
                borderRadius: 2,
                mb: 0.5,
                minHeight: 44,
                px: collapsed && !isMobile ? 1.5 : 2,
                justifyContent: collapsed && !isMobile ? 'center' : 'flex-start',
                '&.Mui-selected': {
                  bgcolor: 'rgba(255,107,53,0.15)',
                  '& .MuiListItemIcon-root': { color: 'primary.main' },
                  '& .MuiListItemText-primary': { color: 'primary.main', fontWeight: 700 },
                  '&:hover': { bgcolor: 'rgba(255,107,53,0.2)' },
                },
                '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
              }}
            >
              <ListItemIcon sx={{ minWidth: collapsed && !isMobile ? 0 : 36, color: 'text.secondary', mr: collapsed && !isMobile ? 0 : 0 }}>
                {item.icon}
              </ListItemIcon>
              {(!collapsed || isMobile) && (
                <ListItemText primary={item.label} primaryTypographyProps={{ fontSize: '0.875rem', fontWeight: 500 }} />
              )}
            </ListItemButton>
          </Tooltip>
        ))}
      </List>
      <Divider />
      <Box sx={{ p: 2 }}>
        {collapsed && !isMobile ? (
          <Tooltip title={profile?.full_name || 'Usuario'} placement="right">
            <Avatar sx={{ bgcolor: 'primary.main', width: 36, height: 36, mx: 'auto', cursor: 'pointer', fontWeight: 700 }} onClick={e => setAnchorEl(e.currentTarget)}>
              {profile?.full_name?.[0] || 'U'}
            </Avatar>
          </Tooltip>
        ) : (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, cursor: 'pointer' }} onClick={e => setAnchorEl(e.currentTarget)}>
            <Avatar sx={{ bgcolor: 'primary.main', width: 36, height: 36, fontWeight: 700 }}>
              {profile?.full_name?.[0] || 'U'}
            </Avatar>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography variant="body2" fontWeight={600} noWrap>{profile?.full_name || 'Usuario'}</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'capitalize' }}>{profile?.role}</Typography>
            </Box>
          </Box>
        )}
      </Box>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* Desktop Drawer */}
      {!isMobile && (
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            '& .MuiDrawer-paper': { width: drawerWidth, transition: 'width 0.3s', overflow: 'hidden', boxSizing: 'border-box' },
          }}
        >
          {DrawerContent}
        </Drawer>
      )}

      {/* Mobile Drawer */}
      {isMobile && (
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={() => setMobileOpen(false)}
          sx={{ '& .MuiDrawer-paper': { width: DRAWER_WIDTH } }}
        >
          {DrawerContent}
        </Drawer>
      )}

      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <AppBar position="sticky" elevation={0} sx={{ zIndex: theme.zIndex.drawer - 1 }}>
          <Toolbar sx={{ gap: 2 }}>
            {isMobile && (
              <IconButton onClick={() => setMobileOpen(true)} sx={{ color: 'text.primary' }}>
                <MenuIcon />
              </IconButton>
            )}
            <Typography variant="h6" fontWeight={700} sx={{ flex: 1 }}>
              {navItems.find(n => isActive(n.path, n.exact))?.label || 'Panel'}
            </Typography>
            <Tooltip title="Notificaciones">
              <IconButton onClick={() => navigate('/admin/notifications')}>
                <Badge badgeContent={3} color="error">
                  <NotificationsIcon sx={{ color: 'text.secondary' }} />
                </Badge>
              </IconButton>
            </Tooltip>
            <Tooltip title="Cuenta">
              <Avatar sx={{ bgcolor: 'primary.main', width: 36, height: 36, cursor: 'pointer', fontWeight: 700 }} onClick={e => setAnchorEl(e.currentTarget)}>
                {profile?.full_name?.[0] || 'U'}
              </Avatar>
            </Tooltip>
          </Toolbar>
        </AppBar>

        <Box sx={{ flex: 1, p: { xs: 2, md: 3 }, overflow: 'auto' }}>
          <Outlet />
        </Box>
      </Box>

      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}>
        <MenuItem disabled>
          <Typography variant="body2" color="text.secondary">{profile?.full_name}</Typography>
        </MenuItem>
        <Divider />
        <MenuItem onClick={() => { setAnchorEl(null); navigate('/admin/settings'); }}>
          <ListItemIcon><SettingsIcon fontSize="small" /></ListItemIcon>
          Configuración
        </MenuItem>
        <MenuItem onClick={handleSignOut}>
          <ListItemIcon><LogoutIcon fontSize="small" sx={{ color: 'error.main' }} /></ListItemIcon>
          <Typography color="error.main">Cerrar Sesión</Typography>
        </MenuItem>
      </Menu>
    </Box>
  );
}
