import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import Box from '@mui/material/Box';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import BottomNavigation from '@mui/material/BottomNavigation';
import BottomNavigationAction from '@mui/material/BottomNavigationAction';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import { useState } from 'react';
import PersonIcon from '@mui/icons-material/Person';
import AssignmentIcon from '@mui/icons-material/Assignment';
import PaymentIcon from '@mui/icons-material/Payment';
import EventNoteIcon from '@mui/icons-material/EventNote';
import LogoutIcon from '@mui/icons-material/Logout';
import LocalFireDepartmentIcon from '@mui/icons-material/LocalFireDepartment';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { path: '/portal', label: 'Perfil', icon: <PersonIcon /> },
  { path: '/portal/routines', label: 'Rutinas', icon: <AssignmentIcon /> },
  { path: '/portal/payments', label: 'Pagos', icon: <PaymentIcon /> },
  { path: '/portal/attendance', label: 'Asistencia', icon: <EventNoteIcon /> },
];

export default function ClientLayout() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const currentTab = navItems.findIndex(n => n.path === location.pathname);

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: 'background.default' }}>
      <AppBar position="sticky" elevation={0}>
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <LocalFireDepartmentIcon sx={{ color: 'primary.main', fontSize: 28 }} />
            <Typography variant="h6" fontWeight={800}>FitPro<span style={{ color: '#FF6B35' }}>Gym</span></Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="body2" color="text.secondary" sx={{ display: { xs: 'none', sm: 'block' } }}>
              {profile?.full_name}
            </Typography>
            <Avatar sx={{ bgcolor: 'primary.main', width: 36, height: 36, cursor: 'pointer', fontWeight: 700 }} onClick={e => setAnchorEl(e.currentTarget)}>
              {profile?.full_name?.[0] || 'C'}
            </Avatar>
          </Box>
        </Toolbar>
      </AppBar>

      <Box sx={{ flex: 1, p: { xs: 2, md: 3 }, pb: { xs: 8, md: 3 } }}>
        <Outlet />
      </Box>

      {/* Mobile Bottom Nav */}
      <Box sx={{ display: { xs: 'block', md: 'none' }, position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 1100 }}>
        <BottomNavigation
          value={currentTab}
          onChange={(_, v) => navigate(navItems[v].path)}
          sx={{ background: '#141414', borderTop: '1px solid rgba(255,255,255,0.08)', height: 60 }}
        >
          {navItems.map(n => (
            <BottomNavigationAction key={n.path} label={n.label} icon={n.icon} sx={{ color: 'text.secondary', '&.Mui-selected': { color: 'primary.main' } }} />
          ))}
        </BottomNavigation>
      </Box>

      {/* Desktop Tabs */}
      <Box sx={{ display: { xs: 'none', md: 'flex' }, position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)', gap: 1, background: 'rgba(20,20,20,0.95)', backdropFilter: 'blur(20px)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 50, px: 2, py: 1, zIndex: 1100 }}>
        {navItems.map(n => (
          <Button key={n.path} startIcon={n.icon} onClick={() => navigate(n.path)} size="small"
            sx={{ borderRadius: 50, px: 2, color: location.pathname === n.path ? 'primary.main' : 'text.secondary', bgcolor: location.pathname === n.path ? 'rgba(255,107,53,0.15)' : 'transparent' }}>
            {n.label}
          </Button>
        ))}
      </Box>

      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}>
        <MenuItem disabled><Typography variant="body2" color="text.secondary">{profile?.full_name}</Typography></MenuItem>
        <MenuItem onClick={handleSignOut}><ListItemIcon><LogoutIcon fontSize="small" sx={{ color: 'error.main' }} /></ListItemIcon><Typography color="error.main">Cerrar Sesión</Typography></MenuItem>
      </Menu>
    </Box>
  );
}
