import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import theme from './theme';
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute, PublicOnlyRoute } from './routes/ProtectedRoute';

// Public
import Landing from './pages/Landing';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';

// Layouts
import AdminLayout from './layouts/AdminLayout';
import ClientLayout from './layouts/ClientLayout';

// Admin Pages
import AdminDashboard from './pages/admin/Dashboard';
import ClientsPage from './pages/admin/Clients';
import MembershipsPage from './pages/admin/Memberships';
import PaymentsPage from './pages/admin/Payments';
import TrainersPage from './pages/admin/Trainers';
import RoutinesPage from './pages/admin/Routines';
import AttendancePage from './pages/admin/Attendance';
import NotificationsPage from './pages/admin/NotificationsPage';
import SettingsPage from './pages/admin/Settings';

// Client Pages
import ClientProfile from './pages/client/Profile';
import ClientRoutines from './pages/client/Routines';
import ClientPayments from './pages/client/Payments';
import ClientAttendance from './pages/client/AttendanceClient';

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            {/* Public */}
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<PublicOnlyRoute><Login /></PublicOnlyRoute>} />
            <Route path="/register" element={<PublicOnlyRoute><Register /></PublicOnlyRoute>} />

            {/* Admin Panel */}
            <Route path="/admin" element={
              <ProtectedRoute requiredRoles={['admin', 'trainer']}>
                <AdminLayout />
              </ProtectedRoute>
            }>
              <Route index element={<AdminDashboard />} />
              <Route path="clients" element={<ClientsPage />} />
              <Route path="memberships" element={<MembershipsPage />} />
              <Route path="payments" element={<PaymentsPage />} />
              <Route path="trainers" element={<TrainersPage />} />
              <Route path="routines" element={<RoutinesPage />} />
              <Route path="attendance" element={<AttendancePage />} />
              <Route path="notifications" element={<NotificationsPage />} />
              <Route path="settings" element={<SettingsPage />} />
            </Route>

            {/* Client Portal */}
            <Route path="/portal" element={
              <ProtectedRoute>
                <ClientLayout />
              </ProtectedRoute>
            }>
              <Route index element={<ClientProfile />} />
              <Route path="routines" element={<ClientRoutines />} />
              <Route path="payments" element={<ClientPayments />} />
              <Route path="attendance" element={<ClientAttendance />} />
            </Route>
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
