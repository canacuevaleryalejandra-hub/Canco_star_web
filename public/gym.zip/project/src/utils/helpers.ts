import { formatDistanceToNow, format, isAfter, isBefore, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

export const formatCurrency = (amount: number, symbol = '$') =>
  `${symbol} ${amount.toLocaleString('es-CO')}`;

export const formatDate = (date: string | null) => {
  if (!date) return '-';
  try { return format(parseISO(date), 'dd/MM/yyyy', { locale: es }); }
  catch { return '-'; }
};

export const formatDatetime = (date: string | null) => {
  if (!date) return '-';
  try { return format(parseISO(date), 'dd/MM/yyyy HH:mm', { locale: es }); }
  catch { return '-'; }
};

export const timeAgo = (date: string) => {
  try { return formatDistanceToNow(parseISO(date), { addSuffix: true, locale: es }); }
  catch { return ''; }
};

export const isMembershipExpired = (endDate: string | null) => {
  if (!endDate) return false;
  return isBefore(parseISO(endDate), new Date());
};

export const isMembershipExpiringSoon = (endDate: string | null, days = 7) => {
  if (!endDate) return false;
  const expiry = parseISO(endDate);
  const warningDate = new Date();
  warningDate.setDate(warningDate.getDate() + days);
  return isAfter(expiry, new Date()) && isBefore(expiry, warningDate);
};

export const getStatusColor = (status: string): 'success' | 'error' | 'warning' | 'default' | 'info' => {
  switch (status) {
    case 'active': return 'success';
    case 'expired': return 'error';
    case 'inactive': return 'default';
    case 'pending': return 'warning';
    case 'completed': return 'success';
    case 'cancelled': return 'error';
    default: return 'default';
  }
};

export const getStatusLabel = (status: string) => {
  const labels: Record<string, string> = {
    active: 'Activo',
    inactive: 'Inactivo',
    expired: 'Vencido',
    pending: 'Pendiente',
    completed: 'Completado',
    cancelled: 'Cancelado',
  };
  return labels[status] ?? status;
};

export const getPaymentMethodLabel = (method: string) => {
  const labels: Record<string, string> = {
    cash: 'Efectivo',
    card: 'Tarjeta',
    transfer: 'Transferencia',
    nequi: 'Nequi',
    daviplata: 'Daviplata',
  };
  return labels[method] ?? method;
};

export const getDifficultyLabel = (diff: string) => {
  const labels: Record<string, string> = {
    beginner: 'Principiante',
    intermediate: 'Intermedio',
    advanced: 'Avanzado',
  };
  return labels[diff] ?? diff;
};

export const calculateMembershipEndDate = (startDate: string, durationDays: number) => {
  const start = parseISO(startDate);
  start.setDate(start.getDate() + durationDays);
  return format(start, 'yyyy-MM-dd');
};
