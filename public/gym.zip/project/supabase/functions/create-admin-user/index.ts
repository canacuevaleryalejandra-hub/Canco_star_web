import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // Create admin user
    const { data: adminData, error: adminError } = await supabase.auth.admin.createUser({
      email: "admin@fitpro.com",
      password: "admin123",
      email_confirm: true,
      user_metadata: { full_name: "Administrador FitPro", role: "admin" },
    });

    if (adminError && !adminError.message.includes("already registered")) {
      throw adminError;
    }

    const adminUserId = adminData?.user?.id;

    // Upsert profile for admin
    if (adminUserId) {
      await supabase.from("profiles").upsert({
        id: adminUserId,
        full_name: "Administrador FitPro",
        role: "admin",
      }, { onConflict: "id" });
    }

    // Create a demo client user
    const { data: clientData, error: clientError } = await supabase.auth.admin.createUser({
      email: "cliente@fitpro.com",
      password: "cliente123",
      email_confirm: true,
      user_metadata: { full_name: "Carlos López", role: "client" },
    });

    if (clientError && !clientError.message.includes("already registered")) {
      throw clientError;
    }

    const clientUserId = clientData?.user?.id;

    if (clientUserId) {
      await supabase.from("profiles").upsert({
        id: clientUserId,
        full_name: "Carlos López",
        role: "client",
      }, { onConflict: "id" });

      // Get first membership
      const { data: memberships } = await supabase.from("memberships").select("id").limit(1);
      const membershipId = memberships?.[0]?.id ?? null;

      // Create client record linked to this user
      const { data: existingClient } = await supabase
        .from("clients")
        .select("id")
        .eq("user_id", clientUserId)
        .maybeSingle();

      if (!existingClient) {
        await supabase.from("clients").insert({
          user_id: clientUserId,
          first_name: "Carlos",
          last_name: "López",
          email: "cliente@fitpro.com",
          phone: "3001234567",
          document_number: "12345678",
          membership_id: membershipId,
          status: "active",
          start_date: new Date().toISOString().split("T")[0],
          end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        });
      }
    }

    return new Response(
      JSON.stringify({ success: true, message: "Demo users created successfully" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ success: false, error: String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
