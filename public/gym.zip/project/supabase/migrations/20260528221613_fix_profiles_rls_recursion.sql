/*
  # Fix profiles RLS infinite recursion

  The "Admins can view all profiles" policy was querying the profiles table
  itself, causing infinite recursion. Replace it with a check on auth.jwt()
  metadata to avoid recursive policy evaluation.
*/

DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON profiles;

-- Simple self-select based on uid only (no recursion)
-- Admins are identified via user_metadata stored in JWT
CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    (auth.uid() = id)
    OR (auth.jwt() -> 'user_metadata' ->> 'role' = 'admin')
  );

CREATE POLICY "Admins can update all profiles"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    (auth.uid() = id)
    OR (auth.jwt() -> 'user_metadata' ->> 'role' = 'admin')
  )
  WITH CHECK (
    (auth.uid() = id)
    OR (auth.jwt() -> 'user_metadata' ->> 'role' = 'admin')
  );
