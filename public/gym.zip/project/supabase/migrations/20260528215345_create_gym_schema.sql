/*
  # Gym Management System - Core Schema

  ## Overview
  Complete database schema for a gym management system with:
  - Client management
  - Membership plans and assignments
  - Payment tracking
  - Trainer profiles
  - Workout routines and exercises
  - Attendance tracking
  - Notifications
  - Gym settings

  ## Tables
  1. `profiles` - User profiles linked to Supabase Auth (role: admin/trainer/client)
  2. `memberships` - Membership plan types (daily, weekly, monthly, etc.)
  3. `clients` - Client records with membership assignments
  4. `payments` - Payment transactions
  5. `trainers` - Trainer profiles
  6. `routines` - Workout routines
  7. `exercises` - Exercises within routines
  8. `attendance` - Client check-in records
  9. `notifications` - System notifications
  10. `gym_settings` - Global gym configuration

  ## Security
  - RLS enabled on all tables
  - Admins have full access
  - Trainers can view/manage their assigned clients
  - Clients can view their own data
*/

-- ================================================================
-- PROFILES
-- ================================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'client' CHECK (role IN ('admin', 'trainer', 'client')),
  phone text DEFAULT '',
  avatar_url text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can update all profiles"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- ================================================================
-- MEMBERSHIPS
-- ================================================================
CREATE TABLE IF NOT EXISTS memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  duration_days integer NOT NULL DEFAULT 30,
  price numeric(10,2) NOT NULL DEFAULT 0,
  description text DEFAULT '',
  features text[] DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view active memberships"
  ON memberships FOR SELECT
  TO authenticated
  USING (is_active = true OR EXISTS (
    SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
  ));

CREATE POLICY "Admins can insert memberships"
  ON memberships FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

CREATE POLICY "Admins can update memberships"
  ON memberships FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Admins can delete memberships"
  ON memberships FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ================================================================
-- TRAINERS
-- ================================================================
CREATE TABLE IF NOT EXISTS trainers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  full_name text NOT NULL,
  specialty text DEFAULT '',
  phone text DEFAULT '',
  email text DEFAULT '',
  bio text DEFAULT '',
  photo_url text DEFAULT '',
  schedule jsonb DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE trainers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view active trainers"
  ON trainers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert trainers"
  ON trainers FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Admins can update trainers"
  ON trainers FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Admins can delete trainers"
  ON trainers FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ================================================================
-- CLIENTS
-- ================================================================
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  document_number text DEFAULT '',
  phone text DEFAULT '',
  email text NOT NULL,
  address text DEFAULT '',
  birth_date date,
  gender text DEFAULT '' CHECK (gender IN ('male', 'female', 'other', '')),
  photo_url text DEFAULT '',
  membership_id uuid REFERENCES memberships(id) ON DELETE SET NULL,
  trainer_id uuid REFERENCES trainers(id) ON DELETE SET NULL,
  start_date date,
  end_date date,
  status text DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'expired', 'pending')),
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all clients"
  ON clients FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Clients can view own record"
  ON clients FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can insert clients"
  ON clients FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Admins can update clients"
  ON clients FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Admins can delete clients"
  ON clients FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ================================================================
-- PAYMENTS
-- ================================================================
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  membership_id uuid REFERENCES memberships(id) ON DELETE SET NULL,
  amount numeric(10,2) NOT NULL DEFAULT 0,
  payment_method text DEFAULT 'cash' CHECK (payment_method IN ('cash', 'card', 'transfer', 'nequi', 'daviplata')),
  payment_date date DEFAULT CURRENT_DATE,
  reference text DEFAULT '',
  status text DEFAULT 'completed' CHECK (status IN ('completed', 'pending', 'cancelled')),
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all payments"
  ON payments FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Clients can view own payments"
  ON payments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM clients c WHERE c.id = payments.client_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can insert payments"
  ON payments FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Admins can update payments"
  ON payments FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Admins can delete payments"
  ON payments FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ================================================================
-- ROUTINES
-- ================================================================
CREATE TABLE IF NOT EXISTS routines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  trainer_id uuid REFERENCES trainers(id) ON DELETE SET NULL,
  title text NOT NULL,
  description text DEFAULT '',
  days_per_week integer DEFAULT 3,
  duration_weeks integer DEFAULT 4,
  difficulty text DEFAULT 'intermediate' CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
  goal text DEFAULT '',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE routines ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins and trainers can view all routines"
  ON routines FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Clients can view own routines"
  ON routines FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM clients c WHERE c.id = routines.client_id AND c.user_id = auth.uid())
  );

CREATE POLICY "Admins and trainers can insert routines"
  ON routines FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Admins and trainers can update routines"
  ON routines FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Admins can delete routines"
  ON routines FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ================================================================
-- EXERCISES
-- ================================================================
CREATE TABLE IF NOT EXISTS exercises (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  routine_id uuid REFERENCES routines(id) ON DELETE CASCADE,
  name text NOT NULL,
  muscle_group text DEFAULT '',
  sets integer DEFAULT 3,
  reps text DEFAULT '10',
  rest_seconds integer DEFAULT 60,
  notes text DEFAULT '',
  day_number integer DEFAULT 1,
  order_index integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE exercises ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins and trainers can view exercises"
  ON exercises FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Clients can view own exercises"
  ON exercises FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM routines r
      JOIN clients c ON c.id = r.client_id
      WHERE r.id = exercises.routine_id AND c.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins and trainers can insert exercises"
  ON exercises FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Admins and trainers can update exercises"
  ON exercises FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Admins can delete exercises"
  ON exercises FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ================================================================
-- ATTENDANCE
-- ================================================================
CREATE TABLE IF NOT EXISTS attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  check_in timestamptz DEFAULT now(),
  check_out timestamptz,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all attendance"
  ON attendance FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Clients can view own attendance"
  ON attendance FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM clients c WHERE c.id = attendance.client_id AND c.user_id = auth.uid())
  );

CREATE POLICY "Admins can insert attendance"
  ON attendance FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Admins can update attendance"
  ON attendance FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'trainer')));

CREATE POLICY "Admins can delete attendance"
  ON attendance FOR DELETE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ================================================================
-- NOTIFICATIONS
-- ================================================================
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  type text DEFAULT 'info' CHECK (type IN ('info', 'warning', 'success', 'error')),
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can insert notifications"
  ON notifications FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- ================================================================
-- GYM SETTINGS
-- ================================================================
CREATE TABLE IF NOT EXISTS gym_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  gym_name text DEFAULT 'FitPro Gym',
  slogan text DEFAULT 'Transform Your Body, Transform Your Life',
  address text DEFAULT '',
  phone text DEFAULT '',
  email text DEFAULT '',
  website text DEFAULT '',
  logo_url text DEFAULT '',
  cover_url text DEFAULT '',
  facebook text DEFAULT '',
  instagram text DEFAULT '',
  twitter text DEFAULT '',
  tax_rate numeric(5,2) DEFAULT 0,
  currency text DEFAULT 'USD',
  currency_symbol text DEFAULT '$',
  opening_time time DEFAULT '06:00',
  closing_time time DEFAULT '22:00',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE gym_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view gym settings"
  ON gym_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Admins can update gym settings"
  ON gym_settings FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "Admins can insert gym settings"
  ON gym_settings FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ================================================================
-- SEED DATA
-- ================================================================
INSERT INTO gym_settings (id, gym_name, slogan, address, phone, email, currency, currency_symbol)
VALUES (
  gen_random_uuid(),
  'FitPro Gym',
  'Transform Your Body, Transform Your Life',
  'Av. Principal 123, Bogotá, Colombia',
  '+57 300 123 4567',
  'info@fitprogym.com',
  'COP',
  '$'
) ON CONFLICT DO NOTHING;

INSERT INTO memberships (name, duration_days, price, description, features) VALUES
  ('Diario', 1, 15000, 'Acceso por un día', ARRAY['Acceso a todas las áreas', 'Casillero incluido']),
  ('Semanal', 7, 60000, 'Acceso por una semana', ARRAY['Acceso a todas las áreas', 'Casillero incluido', 'Evaluación física']),
  ('Mensual', 30, 120000, 'Acceso por un mes', ARRAY['Acceso a todas las áreas', 'Casillero incluido', 'Evaluación física', '1 sesión con entrenador']),
  ('Trimestral', 90, 320000, 'Acceso por tres meses', ARRAY['Acceso a todas las áreas', 'Casillero incluido', 'Evaluación física', '3 sesiones con entrenador', 'Plan nutricional']),
  ('Anual', 365, 1100000, 'Acceso por un año', ARRAY['Acceso a todas las áreas', 'Casillero incluido', 'Evaluación física', 'Sesiones ilimitadas con entrenador', 'Plan nutricional', 'Acceso 24/7'])
ON CONFLICT DO NOTHING;

-- ================================================================
-- INDEXES
-- ================================================================
CREATE INDEX IF NOT EXISTS idx_clients_email ON clients(email);
CREATE INDEX IF NOT EXISTS idx_clients_status ON clients(status);
CREATE INDEX IF NOT EXISTS idx_clients_membership_id ON clients(membership_id);
CREATE INDEX IF NOT EXISTS idx_payments_client_id ON payments(client_id);
CREATE INDEX IF NOT EXISTS idx_payments_payment_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_attendance_client_id ON attendance(client_id);
CREATE INDEX IF NOT EXISTS idx_attendance_check_in ON attendance(check_in);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_routines_client_id ON routines(client_id);
